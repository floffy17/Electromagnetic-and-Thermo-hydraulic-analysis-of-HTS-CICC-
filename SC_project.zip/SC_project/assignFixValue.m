function [A,b,idUnk] = assignFixValue(A,b,idFix,xfix,varargin)

% ASSIGNFIXVALUE assigns to certain idfix a prefixed xfix and rearrange
% the solving matrix and rhs taking into account equivalues
%
% USE:
% [A,b,idUnk] = assignFixValue(A,b,idfix,xfix,varargin)
%
% INPUTS:
% 'A': solve matrix
% 'b': rhs
% 'idfix': indices of idfix with assigned values (e.g. Dirichlet boundary conditions)
% 'xfix': values to be assigned to idfix
% 'varargin': optional arguments
%   * 'equivalue': MX1 cell array with groups of equivalue unknowns
%   * 'binary': Mx5 matrix with binary constraints [i1 i2 k1 k2 k3] such that
%       alpha*x(i1)+beta*x(i2) = gamma
%
% OUTPUTS:
% 'A': modified solve matrix
% 'b': modified rhs
% 'idUnk': absolute indices of unknowns
%
% NOTE:
% To mantain the diagonal dominance, once a column is removed from the
% system, the row with the same index is also removed
%
% VERSION:
% Date: 19.12.2009
% Copyright(C) 2009-2015: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
% 21.06.2010: removed repeated assignments
% 26.08.2013: changed variable names
% 26.08.2013: added EQUIVALUE as optional input
% 27.11.2013: can handle empty IDFIX/XFIX
% 28.02.2014: added binary constraints
% 22.04.2015: changed the sintax of binary constraints

% default inputs
equivalue = cell(0);
binary = [];

% check varargin
for i = 1:2:length(varargin)
    vin = varargin{i};
    if isequal(vin,'equivalue')
        equivalue = varargin{i+1};
    elseif isequal(vin,'binary')
        binary = varargin{i+1};
    end
end

% remove repeated assignments
[idFix,iElm] = unique(idFix);

% fixed values
if ~isempty(idFix)
    %b = b-repmat(A(:,idfix)*xfix(ielems),1,size(b,2));
    b = b-A(:,idFix)*xfix(iElm,:);
end

% floating values
idRem = [];

% equipotential unknowns
if ~isempty(equivalue)
    for i = 1:length(equivalue)
        idEq = equivalue{i};
        
        % column sum
        A(:,idEq(1)) = sum(A(:,idEq),2);
        idRem = [idRem; idEq(2:end)];
        
        % row sum
        A(idEq(1),:) = sum(A(idEq,:),1);
        b(idEq(1),:) = sum(b(idEq,:),1);
    end
    
end

% binary constraints
if ~isempty(binary)
    i1 = abs(binary(:,1));
    i2 = abs(binary(:,2));
    alpha = binary(:,3);
    beta = binary(:,4);
    gamma = binary(:,5);
    %    k = binary(:,3);
    for i = 1:length(i1)
        
        %         % column sum
        %         A(:,i1(i)) = A(:,i1(i))+A(:,i2(i));
        %         b = b+k(i)*A(:,i2(i));
        %
        %         % row sum
        %         A(i1(i),:) = A(i1(i),:)+A(i2(i),:);
        %         b(i1(i),:) = b(i1(i),:)+b(i2(i),:);
        
        
        %         % column sum
        %         A(:,i1(i)) = A(:,i1(i))-sign(i1(i))*sign(i2(i))*A(:,i2(i));
        %         b = b-k(i)*sign(i2(i))*A(:,i2(i));
        %
        %         % row sum
        %         A(i1(i),:) = A(i1(i),:)-sign(i1(i))*sign(i2(i))*A(i2(i),:);
        %         b(i1(i),:) = b(i1(i),:)-sign(i1(i))*sign(i2(i))*b(i2(i),:);
        
        % column sum
        A(:,i1(i)) = A(:,i1(i))-alpha(i)*A(:,i2(i))/beta(i);
        b = b-gamma(i)*A(:,i2(i))/beta(i);
        
        % row sum
        A(i1(i),:) = A(i1(i),:)-alpha(i)*A(i2(i),:)/beta(i);
        b(i1(i),:) = b(i1(i),:)-alpha(i)*b(i2(i),:)/beta(i);
        
    end
else
    i2 = [];
end


% delete rows and column
idUnk = setdiff((1:size(b,1)).',[idFix(:); idRem(:); i2(:)]);

A = A(:,idUnk);
A = A(idUnk,:);
% A = A(idunk,idunk);
b = b(idUnk,:);