function x = assembleSolution(x0,dim,idx,idFix,xFix,varargin)

% ASSEMBLESOLUTION merges the solution with the fixed values, equivalues
% and binary constraints
%
% USE:
% x = assembleSolution(x0,dim,idx,idFix,xFix,varargin)
%
% INPUTS:
% 'x0': solution
% 'dim': dimensions of the complete solution
% 'idx': indices of unknowns
% 'idFix': vector containing indices of assigned variables
% 'xFix': vector containing assigned values
% 'varargin': optional arguments
%   * 'equivalue': MX1 cell array with groups of equivalue unknowns
%   * 'binary': Mx5 matrix with binary constraints [i1 i2 k1 k2 k3] such that
%       alpha*x(i1)+beta*x(i2) = gamma
%
% OUTPUTS:
% 'x': complete vector of unknowns
%
% NOTE:
% - see also ASSIGNFIXVALUES
%
% VERSION:
% Date: 03.07.2024
% Copyright(C) 2024: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
% 10.07.2024: final solution
% 25.09.2024: EQUIVALUE and BINARY as optional inputs

% default inputs
equivalue = cell(0);
binary = [];

% check varargin
for i = 1:2:length(varargin)
    vin = varargin{i};
    if isequal(vin,'equivalue')
        equivalue = varargin{i+1};
    elseif isequal(vin,'binary')
        binary = varargin{i+1};
    end
end

% preallocation
x = zeros(dim);

% assembling complete solution
x(idx,:) = x0;

% add fixed values
if ~isempty(idFix)
    x(idFix,:) = xFix;
end

% add equivalues
for i = 1:length(equivalue)
    x(equivalue{i},:) = x(equivalue{i}(1),:);
    % idx = equivalue{i};
    % x(idx,:) = repmat(x(idx(1),:),length(idx),1);
end

% add binary constraints
for i = 1:size(binary,1)
    x(abs(binary(i,2)),:) = (binary(i,5)-binary(i,3)*x(abs(binary(i,1)),:))/binary(i,4);
end

end