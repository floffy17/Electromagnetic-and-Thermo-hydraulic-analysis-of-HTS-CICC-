function M = inductanceMatrix1d(P,E,r0)

% INDUCTANCECALCULATION calculates the inductance matrix of segments in 3d space
%
%
% USE:
% M = inductanceCalculation(P,E,r0)
%
% INPUTS:
% 'primal': struct of primal mesh, as created by CREATEPRIMAL3D
% 'mat': struct of the material properties, as created by SETMATPROPERTIES
%
% OUTPUT:
% 'M': inductance matrix
%
% NOTE:
% Adapted from INDUCTANCEMATRIX1D
% See Grover f., "Inductance Calculation", 1973
%
% VERSION:
% Date: 25.06.2021
% Copyright(C) 2021: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:

% default inputs
RelTol = 1e-4;
AbsTol = 1e-4;

% start node
P1 = P(E(:,1),:);
% end node
P2 = P(E(:,2),:);

% edge length
L = P2-P1;
Lmod = sqrt(sum(L.^2,2));
nEdg = size(L,1);

% preallocation
M = zeros(nEdg);

for i = 1:nEdg    
    % start point and vector
    Qi = P1(i,:);
    Vi = L(i,:);
    for j = i+1:nEdg
        % start point and vector
        Qj = P1(j,:);
        Vj = L(j,:);
        
        % reverse of distance
        Gij = @(ti,tj)1./sqrt((Qi(1)+ti*Vi(1)-Qj(1)-tj*Vj(1)).^2+(Qi(2)+ti*Vi(2)-Qj(2)-tj*Vj(2)).^2+(Qi(3)+ti*Vi(3)-Qj(3)-tj*Vj(3)).^2);
        
        % mutual inductance
        M(i,j) = sum(Vi.*Vj)*integral2(Gij,0,1,0,1,'RelTol',RelTol,'AbsTol',AbsTol);

%         % simplified approach
%         Rij = sqrt(sum(((P2(i,:)+P1(i,:))/2-(P2(j,:)+P1(j,:))/2).^2,2));
%         M(i,j) = dotProduct(Vi,Vj)/Rij;

    end
end

% self inductances
Lself = 2*(Lmod.*log((Lmod+sqrt(Lmod.^2+r0.^2))./r0)-sqrt(Lmod.^2+r0.^2)+Lmod/4+r0);

% internal inductance (factor Mu0/(4*pi) added later)
Lint = Lmod/2;

% build matrix
M = Mu0/(4*pi)*(diag(Lself+Lint)+M+M.');

end