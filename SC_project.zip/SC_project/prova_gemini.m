clc; 
clear all; 
close all;

% ========================================================================
%  PROGETTO: MODELLAZIONE PEEC DI UN MAGNETE SUPERCONDUTTORE HTS (15 T)
%  ========================================================================

% PARTE 1: MODELLO MACROSCOPICO DEL SOLENOIDE (Generatore di B_ext)
% Obiettivo: Costruire un solenoide semplificato (1D filiforme) per calcolare 
% il campo magnetico di background che investirà il double-pancake centrale.

% --- 1. Parametri Geometrici del Solenoide ---
R_in = 0.5;                 % [m] Raggio interno dettato dalle specifiche.
H_max = 1.5;                % [m] Altezza totale massima del magnete.
spessore_cavo = 0.025;      % [m] Diametro esterno reale del CICC (25 mm) dedotto dai disegni ENEA.
N_layer = 16;               % Numero di strati concentrici. Calcolato iterativamente per ottenere ~14.9 T.
N_spire_per_layer = 30;     % Spire lungo l'asse Z. Lascia spazio (~25mm extra a spira) per isolamento e raffreddamento.
N_seg_spira = 32;           % Discretizzazione: approssimiamo ogni cerchio con un poligono di 32 lati.

% Inizializzazione delle matrici che conterranno l'intera geometria macroscopica
P_macro = [];               % Matrice dei Nodi [X, Y, Z]
E_macro = [];               % Matrice degli Archi [NodoIniziale, NodoFinale]
offset_nodi = 0;            % Variabile di servizio: serve a numerare progressivamente i nodi tra i vari layer.

fprintf('Generazione Solenoide Macroscopico in corso...\n');

% --- 2. Costruzione dei Layer del Solenoide ---
for i_layer = 1:N_layer
    % Raggio del layer corrente: partiamo da R_in e ci allarghiamo di 25mm ad ogni strato
    R_layer = R_in + (i_layer - 1) * spessore_cavo;
    
    % Vettore theta: definisce l'angolo per l'elica. Va da 0 fino a (2*pi * numero spire totali)
    theta = linspace(0, 2*pi*N_spire_per_layer, N_spire_per_layer * N_seg_spira + 1)';
    
    % Coordinate X e Y per descrivere il movimento circolare
    X = R_layer * cos(theta);
    Y = R_layer * sin(theta);
    
    % Coordinata Z: Il solenoide deve essere centrato in Z=0. 
    % Quindi Z va da -0.75m a +0.75m per avere l'equatore esattamente nell'origine.
    Z = linspace(-H_max/2, H_max/2, length(theta))';
    
    % Accodiamo i nodi di questo layer alla matrice globale P_macro
    P_layer = [X, Y, Z];
    P_macro = [P_macro; P_layer];
    
    % --- 3. Creazione degli Archi (Matrice E) ---
    % Creiamo i collegamenti tra i nodi consecutivi per formare il filo continuo dell'elica.
    nodi_elica = (1:(length(theta)-1))' + offset_nodi;
    E_layer = [nodi_elica, nodi_elica + 1];
    
    % Accodiamo gli archi alla matrice globale E_macro
    E_macro = [E_macro; E_layer];
    
    % Aggiorniamo l'offset: il prossimo layer inizierà a contare i nodi da dove è arrivato questo.
    offset_nodi = offset_nodi + length(theta);
end

fprintf('Solenoide completato: %d layer, %d nodi totali.\n', N_layer, size(P_macro, 1));

% --- 4. TEST DEL CAMPO MAGNETICO AL CENTRO ---
I_nominale = 50e3; % [A] Corrente di targa del progetto (50 kA).
Is_macro = I_nominale * ones(size(E_macro, 1), 1); % Vettore che assegna 50kA a ogni segmento.

Q_test = [0, 0, 0]; % Punto in cui misurare il campo (centro assoluto del magnete).

fprintf('Calcolo del campo magnetico al centro (Biot-Savart)...\n');
% segmentMagneticField1d applica la legge di Biot-Savart a tutti i segmenti.
H_centro = segmentMagneticField1d(P_macro, E_macro, Is_macro, Q_test);
B_centro = Mu0() * H_centro; % Passaggio da campo H [A/m] a induzione magnetica B [T].

B_modulo_centro = norm(B_centro); % Calcolo dell'intensità totale del vettore 3D.
fprintf('--> Campo B generato al centro: %.2f Tesla\n', B_modulo_centro);


%% PARTE 2: MODELLO MICROSCOPICO PEEC (Double Pancake Centrale)
% Obiettivo: Costruire la topologia dettagliata (80 nastri twistati) di un singolo 
% Double-Pancake situato all'equatore per l'analisi PEEC.

% --- 1. Parametri Macroscopici del Double Pancake ---
R_in = 0.5;                 % [m] Il raggio interno è lo stesso del magnete globale.
pitch = 0.025;              % [m] Ingombro del cavo (25 mm). Serve per spaziare i giri e i pancake.
N_turns_dp = 16;             % MANTENIAMO 3 GIRI PER SICUREZZA RAM (Evita l'esplosione della matrice L).
N_seg_turn = 32;            % Stessa discretizzazione del macro.

% --- 2. Parametri Microscopici (Layout Interno del Cavo) ---
N_slots = 6;                % Numero di scanalature (slot) nel core in alluminio/rame.
N_tapes = 1;               % Numero di nastri superconduttori per ogni slot.
twist_pitch = 0.5;          % [m] Passo di twistatura: ogni mezzo metro i nastri fanno un giro completo.
R_core = 0.005;             % [m] Raggio del core centrale (stimato per far spazio a 4 slot).
t_tape = 0.0001;            % [m] Spessore di un singolo nastro (100 micrometri).

fprintf('\nGenerazione Double Pancake: %d slot, %d nastri/slot...\n', N_slots, N_tapes);

% --- 3. Generazione Linea Centrale (Sviluppo spaziale del cavo) ---
% PANCAKE INFERIORE: Spirale che parte da R_in e si allarga.
theta_1 = linspace(0, 2*pi*N_turns_dp, N_turns_dp * N_seg_turn + 1)';
r_1 = R_in + (pitch / (2*pi)) * theta_1; % Il raggio cresce proporzionalmente all'angolo.
Z_1 = -(pitch / 2) * ones(size(theta_1)); % Spostato sotto l'asse Z=0 di mezzo diametro del cavo.
P_center_1 = [r_1 .* cos(theta_1), r_1 .* sin(theta_1), Z_1];

% PANCAKE SUPERIORE: Spirale che parte dal raggio massimo e si stringe verso R_in.
theta_2 = linspace(2*pi*N_turns_dp, 4*pi*N_turns_dp, N_turns_dp * N_seg_turn + 1)';
r_max = r_1(end);
r_2 = r_max - (pitch / (2*pi)) * (theta_2 - 2*pi*N_turns_dp); % Il raggio decresce.
Z_2 = (pitch / 2) * ones(size(theta_2)); % Spostato sopra l'asse Z=0 di mezzo diametro.
P_center_2 = [r_2 .* cos(theta_2), r_2 .* sin(theta_2), Z_2];

% UNIONE: Rimuoviamo la riga 1 del pancake superiore per non avere un nodo doppio nel layer jump.
P_center = [P_center_1; P_center_2(2:end, :)];
N_nodes_center = size(P_center, 1);

% --- 4. Sistema di Riferimento Locale (Frenet-Serret) per il Twist ---
dP = diff(P_center, 1, 1);       % Vettori differenza tra nodi consecutivi.
ds = sqrt(sum(dP.^2, 2));        % Lunghezza di ogni segmento.
s = [0; cumsum(ds)];             % Coordinata curvilinea: tiene traccia di quanti metri di cavo abbiamo percorso.

% Vettore TANGENTE (T): Direzione in cui punta il cavo in ogni nodo.
T = zeros(N_nodes_center, 3);
T(1:end-1, :) = dP ./ ds;        % Normalizzazione.
T(end, :) = T(end-1, :);         % L'ultimo nodo eredita la tangente del precedente.

% Vettore NORMALE (N): Punta sempre radialmente verso l'esterno del toroide.
Z_vec = repmat([0, 0, 1], N_nodes_center, 1);
N = cross(Z_vec, T, 2);          % Prodotto vettoriale tra Z e Tangente.
N = N ./ vecnorm(N, 2, 2);       % Normalizzazione.

% Vettore BINORMALE (B): Perpendicolare a T e N, definisce "l'alto" locale del cavo.
B = cross(T, N, 2); 

% --- 5. Generazione Matrici P_micro ed E_micro per gli 80 nastri ---
P_micro = [];
E_micro = [];
node_offset = 0; % Fondamentale: garantisce che ogni nastro abbia indici dei nodi unici.

for i_slot = 1:N_slots
    % Angolo base di partenza per questo slot (es. 0, 90, 180, 270 gradi).
    theta_slot = (i_slot - 1) * (2*pi / N_slots); 
    
    for i_tape = 1:N_tapes
        % Il raggio locale del nastro dipende dalla sua posizione nella pila (stack).
        r_tape = R_core + (i_tape - 1) * t_tape;
        
        % Angolo di Twist: somma dell'angolo dello slot e della rotazione elicoidale 
        % che dipende da quanti metri di cavo abbiamo percorso (s).
        alpha = theta_slot + (2*pi / twist_pitch) * s;
        
        % Calcolo offset 3D rispetto alla linea centrale usando N e B
        dx = N(:,1) .* (r_tape .* cos(alpha)) + B(:,1) .* (r_tape .* sin(alpha));
        dy = N(:,2) .* (r_tape .* cos(alpha)) + B(:,2) .* (r_tape .* sin(alpha));
        dz = N(:,3) .* (r_tape .* cos(alpha)) + B(:,3) .* (r_tape .* sin(alpha));
        
        % Sommiamo l'offset alla linea centrale per trovare le vere coordinate del nastro.
        P_tape = P_center + [dx, dy, dz];
        P_micro = [P_micro; P_tape];
        
        % Creiamo gli archi per questo nastro specifico.
        nodes = (1:N_nodes_center-1)' + node_offset;
        E_micro = [E_micro; nodes, nodes+1];
        
        % Aggiorniamo l'offset per non sovrascrivere i nodi col prossimo nastro.
        node_offset = node_offset + N_nodes_center;
    end
end

fprintf('Nodi totali (P_micro): %d | Archi totali (E_micro): %d\n', size(P_micro, 1), size(E_micro, 1));


%% PARTE 3: CALCOLO MATRICE DELLE INDUTTANZE (L)
% Obiettivo: Calcolare gli accoppiamenti magnetici (auto e mutua induttanza) 
% tra tutti i segmenti degli 80 nastri superconduttori che compongono il modello.

fprintf('\n--- Avvio calcolo Matrice delle Induttanze (L) ---\n');

% 1. Definizione Geometrica del singolo nastro HTS per l'auto-induttanza
w_tape = 0.004;  % [m] Larghezza reale del nastro REBCO (4 mm).
t_tape = 0.0001; % [m] Spessore reale del nastro (100 micrometri).

% Calcolo del Raggio Equivalente basato sulla conservazione dell'area geometrica.
% Spiegazione fisica: La funzione induttiva 1D del professore richiede un raggio cilindrico 
% per evitare la singolarità matematica (divisione per zero) durante il calcolo 
% dell'auto-induttanza del segmento su se stesso (elementi sulla diagonale principale).
r_eq = sqrt((w_tape * t_tape) / pi); 
fprintf('Raggio equivalente calcolato (r0): %.4f mm\n', r_eq * 1000);

% 2. Generazione della Matrice delle Induttanze L
fprintf('Calcolo L in corso... (Operazione CPU-intensive, richiede tempo!)\n');
tic; % Avviamo il cronometro interno di MATLAB per misurare le prestazioni.

% La funzione applica l'equazione integrale di Neumann tramite integral2 per le mutue induttanze 
% e la formula analitica del cilindro per le auto-induttanze (sulla diagonale) usando r_eq.
L = inductanceMatrix1d(P_micro, E_micro, r_eq);
tempo_L = toc; % Fermiamo il cronometro e salviamo il tempo impiegato in secondi.

% 3. Ottimizzazione Numerica e Sanity Check (FONDAMENTALE)
% Spiegazione matematica: Gli errori di troncamento del processore (floating-point a 64 bit) 
% possono creare infinitesimali asimmetrie numeriche (es. L(i,j) diverso da L(j,i)). 
% Forziamo la simmetria perfetta del sistema facendo la media algebrica con la sua trasposta (L'). 
% Questo passaggio previene il crash del solutore delle equazioni differenziali (ode15s).
L = (L + L') / 2;

% 4. Diagnostica della memoria allocata
info_L = whos('L'); % Estraiamo i metadati della variabile L dal Workspace.
memoria_MB = info_L.bytes / (1024^2); % Convertiamo i byte totali in Megabyte per renderli leggibili.
fprintf('Matrice L completata in %.2f secondi! (RAM occupata: %.2f MB)\n', tempo_L, memoria_MB);

% 5. Salvataggio permanente dei dati sul disco rigido (File di Backup)
% Spiegazione ingegneristica: Poiché questo calcolo richiede molto tempo, scriviamo 
% la matrice L e le matrici geometriche associate direttamente in un file fisico '.mat'.
% L'opzione '-v7.3' è obbligatoria perché abilita il supporto a file di grandi dimensioni 
% (HDF5) necessari quando le matrici superano la soglia dei 2 GB.
fprintf('Salvataggio delle matrici sul disco rigido in corso...\n');
save('Matrici_DoublePancake.mat', 'L', 'P_micro', 'E_micro', '-v7.3');

% 6. Conferma visiva dell'avvenuta protezione dei dati
fprintf('--> Matrici salvate con successo nel file: Matrici_DoublePancake.mat\n');

% load('Matrici_DoublePancake.mat'); % per riprendere la matrice salvata
% %% PARTE 4: MATRICI TOPOLOGICHE (A e G) - MODELLO JACKET ASIMMETRICO
% % Obiettivo: Implementare la mesh trasversale del Jacket (Slide 31-33).
% % Il jacket funge da shunt: Rame sui lati/fondo, Acciaio sulla parte superiore.
% 
% fprintf('\n--- Avvio calcolo Matrici Topologiche (Modello Jacket Rame/Acciaio) ---\n');
% 
% % --- 1. MATRICE DI INCIDENZA (A) ---
% N_nodes_micro = size(P_micro, 1);
% N_arcs_micro = size(E_micro, 1);
% A = sparse(E_micro(:,1), 1:N_arcs_micro, -1, N_nodes_micro, N_arcs_micro) + ...
%     sparse(E_micro(:,2), 1:N_arcs_micro, 1, N_nodes_micro, N_arcs_micro);
% 
% % --- 2. PARAMETRI DEI MATERIALI DEL JACKET ---
% % Conduttività tipiche a 4.2 K (considerando l'effetto magnetico se necessario)
% sigma_Cu = 5e9;  % [S/m] Rame (molto alta a temperature criogeniche)
% sigma_SS = 2e6;  % [S/m] Acciaio Inox (molto più bassa del rame)
% 
% % Calcolo delle conduttanze trasversali (G = sigma * Area_trasv / distanza)
% % Questi valori andranno poi calibrati con i dati geometrici esatti delle slide.
% G_rame    = 1e6; % Rappresenta il percorso attraverso il fondo/lati (Rame)
% G_acciaio = 1e3; % Rappresenta il percorso attraverso la cima (Acciaio)
% 
% G = sparse(N_nodes_micro, N_nodes_micro);
% 
% % --- 3. COSTRUZIONE DELLA MESH 2D (4 DIREZIONI) ---
% for i_slot = 1:N_slots
%     for i_tape = 1:N_tapes
% 
%         % Indici dei nodi del nastro corrente
%         idx_curr = ((i_slot - 1) * N_tapes + (i_tape - 1)) * N_nodes_center + (1:N_nodes_center)';
% 
%         % --- DIREZIONE SOPRA (ACCIAIO) ---
%         % Se il nastro ha un vicino sopra, o se è l'ultimo in alto (verso il jacket di acciaio)
%         if i_tape < N_tapes
%             idx_above = ((i_slot - 1) * N_tapes + i_tape) * N_nodes_center + (1:N_nodes_center)';
%             % Usiamo G_acciaio se stiamo modellando la connessione verso la parte alta
%             G = G + sparse(idx_curr, idx_above, -G_acciaio, N_nodes_micro, N_nodes_micro);
%             G = G + sparse(idx_above, idx_curr, -G_acciaio, N_nodes_micro, N_nodes_micro);
%             G = G + sparse(idx_curr, idx_curr, G_acciaio, N_nodes_micro, N_nodes_micro);
%             G = G + sparse(idx_above, idx_above, G_acciaio, N_nodes_micro, N_nodes_micro);
%         end
% 
%         % --- DIREZIONE SOTTO (RAME) ---
%         % Se il nastro ha un vicino sotto, o guarda verso il fondo del jacket
%         if i_tape > 1
%             idx_below = ((i_slot - 1) * N_tapes + (i_tape - 2)) * N_nodes_center + (1:N_nodes_center)';
%             G = G + sparse(idx_curr, idx_below, -G_rame, N_nodes_micro, N_nodes_micro);
%             G = G + sparse(idx_below, idx_curr, -G_rame, N_nodes_micro, N_nodes_micro);
%             G = G + sparse(idx_curr, idx_curr, G_rame, N_nodes_micro, N_nodes_micro);
%             G = G + sparse(idx_below, idx_below, G_rame, N_nodes_micro, N_nodes_micro);
%         end
% 
%         % --- DIREZIONI LATERALI: DESTRA E SINISTRA (RAME) ---
%         % Qui colleghiamo il nastro ai "lati" del jacket in rame.
%         % Fisicamente, aggiungiamo termini diagonali che rappresentano la 
%         % dispersione verso il jacket di rame laterale.
%         G = G + sparse(idx_curr, idx_curr, 2 * G_rame, N_nodes_micro, N_nodes_micro);
%     end
% end
% 
% fprintf('Matrice G completata: Mesh 4-direzioni con Jacket asimmetrico (Rame/Acciaio).\n');