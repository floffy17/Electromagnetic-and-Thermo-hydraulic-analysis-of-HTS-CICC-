function structure = checkMatrixStructure(M,varargin)

% CHECKMATRIXSTRUCTURE checks if matrix is diagonal, symmetric hermitian
%
% USE:
% structure = checkMatrixStructure(M,varargin)
%
% INPUT:
% 'M': matrix
% 'varargin': optional arguments
%   * 'verbose': verbose output. Available: 'y' yes, 'n' no (default: 'y')
%   * 'threshold': optional value of threshold (default 1e-6)
%
% OUTPUT:
% 'structure': matrix structure ('diagonal', 'symmetric', 'hermitian', 'unsymmetric'
%
% NOTE:
% Works with real/complex matrices
% Small entries can cause error in symmetry check. Use DROPTOL before
%
% VERSION:
% Date: 02.07.2024
% Copyright(C) 2024: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
% 03.07.2024: added normalization
% 09.07.2024: final version
% 18.09.2024: fixed the creation of diagonal values

% default inputs
verbose = 'y';
threshold = 1e-6;

% check varargin
for i = 1:2:length(varargin)
    vin = varargin{i};
    if strcmpi(vin,'verbose')
        verbose = varargin{i+1};
    elseif strcmpi(vin,'threshold')
        threshold = varargin{i+1};
    end
end

% printing logical variable
iprn = strcmpi(verbose,'y');

cprintf(iprn,'* Structure check... ');
t0 = tic;

%% diagonal check
% extract diagonal values
d = abs(diag(M));
d(d == 0) = 1;
diagM = spdiags(d,0,size(M,1),size(M,2));
% diagM = abs(diag(max(diag(M),1)));

% check for diagonal matrices
if isdiag(M)
    structure = 'diagonal';
    cprintf(iprn,'done %6.2f sec\n',toc(t0));
    return
end

%% symmetric check
% nonsymmetric part
dM = M-M.';

% normalize nonsimmetric part with respect to diagonal values
[~,~,m] = find(diagM\dM);
% mNorm = abs(m)./max(diagM(iRow),1);

% check for (approximate) symmetry
if all(abs(m) < threshold)
    structure = 'symmetric';
    cprintf(iprn,'done %6.2f sec\n',toc(t0));
    return
end

%% hermitian check
if ~isreal(M)
    % nonsimmetric part
    dM = M-M';

    % normalize nonhermitian part with respect to diagonal values
    [~,~,m] = find(diagM\dM);
    % mNorm = abs(m)./max(diagM(iRow),1);

    % check for hermitian
    if all(abs(m) < threshold)
        structure = 'hermitian';
        cprintf(iprn,'done %6.2f sec\n',toc(t0));
        return
    end
end

%% no structure
structure = 'unsymmetric';
cprintf(iprn,'done %6.2f sec\n',toc(t0));
