function [x,factor,c] = directSolve(A,b,idFix,xFix,varargin)

% DIRECTSOLVE solves the problem Ax = b by removing from the system the unknowns
%              assigned on the boundary
%
% USE:
% [x,factor,c] = directSolve(A,b,idFix,xFix,varargin)
%
% INPUTS:
% 'A': complete coefficient matrix
% 'b': complete rhs
% 'idFix': vector containing indices of assigned variables
% 'xFix': vector containing assigned values
% 'varargin': optional arguments
%   * 'method': algorithm. Options:
%     - 'chol' Cholesky
%     - 'lu' LU factorization,
%     - 'ldl' LDL' factorization
%     - 'mldivide' '\' builtin blackbox backslash
%     - '' automatic choice (default)
%   * 'factor': struct with solution provided in a previous step
%   * 'iterMAX': number of iterative refinement steps
%   * 'verbose': verbose output. Available: 'y' yes, 'n' no (default: 'y')
%   * 'equivalue': MX1 cell array with groups of equivalue unknowns
%   * 'binary': Mx5 matrix with binary constraints [i1 i2 alpha beta gamma] such that
%       alpha*x(i1)+beta*x(i2) = gamma
%
% OUTPUTS:
% 'x': complete vector of unknowns after solution
% 'factor': struct with information on factorization (factors included)
% 'c': estimate of the 1-norm condition number
%
% NOTE:
% - Matrix structure is checked by CHECKMATRIXSTRUCTURE.
% - When alg is undefined it is first checked if A is candidate for CHOL,
%   otherwise LU is used.
% - When CHOL fails, if matrix is real LDL is used
% - When b = [] only factorization is performed
%
% VERSION:
% Date: 19.12.2009
% Copyright(C) 2009-2024: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
% 16.04.2010: added builtin backslash after imposing boundary conditions
% 06.01.2011: when b = [] only factorization is performed
% 19.01.2011: added conditional print
% 14.06.2012: free memory used by HSL86
% 19.06.2012: added field ALG to FACTOR when MLDIVIDE is used
% 26.08.2013: added EQUIVALUE as optional input
% 27.11.2013: moved the management of empty IDFIX to ASSIGNFIXVALUE
% 28.02.2014: added binary constraints
% 03.03.2014: added condition number estimation as output
% 02.04.2014: the number of rows of XFIX must be equal to that of B 
% 19.03.2015: fixed bug of multiple RHS with EQUIVALUE
% 22.04.2015: changed the sintax of binary constraints
% 10.07.2024: refurbished routine

% default inputs
method = '';
factor = struct([]);
iterMAX = 0;
verbose = 'y';
equivalue = cell(0);
binary = [];

% check varargin
for i = 1:2:length(varargin)
    vin = varargin{i};
    if strcmpi(vin,'method')
        method = varargin{i+1};
    elseif strcmpi(vin,'factor')
        factor = varargin{i+1};
    elseif strcmpi(vin,'iterMAX')
        iterMAX = varargin{i+1};
    elseif strcmpi(vin,'verbose')
        verbose = varargin{i+1};
    elseif strcmpi(vin,'equivalue')
        equivalue = varargin{i+1};
    elseif strcmpi(vin,'binary')
        binary = varargin{i+1};
    end
end

% printing logical variable
iprn = strcmpi(verbose,'y');

% print timing
cprintf(iprn,'solving system...\n');
t1 = tic;

% check on rhs
iSolve = true;
if isempty(b)
    b = zeros(size(A,2),1);
    iSolve = false;
end

% reduction of solving system
[A,b,idx] = assignFixValue(A,b,idFix,double(xFix),'equivalue',equivalue,'binary',binary);

if strcmpi(method,'mldivide') || strcmpi(method,'\')
    cprintf(iprn,'* MLDIVIDE... ');
    t2 = tic;
    factor = struct('x',A\b);
    factor.method = method;
    cprintf(iprn,'done %6.2f sec\n',toc(t2));
    
    % computation of condition number
    if nargout == 3
        c = condest(A);
    end
    
else
    % factorization
    if isempty(factor)
        factor = factorizeMatrix(A,'method',method,'verbose',verbose);
    end
    
    % solution
    if iSolve
        x0 = forwardBackwardSolve(factor,b,'verbose',verbose);
        
        % iterative refinement
        if iterMAX > 0
            x0 = iterativeRefinement(A,b,x0,factor,iterMAX,'verbose',verbose);
        end
    else
        x0 = zeros(size(b));
    end
    
    % computation of condition number
    if nargout == 3
        c = cond1est(A,factor);
    end
end

% assembling complete solution
x = assembleSolution(x0,size(b),idx,idFix,xFix,'equivalue',equivalue,'binary',binary);

% x(idx,:) = x0;
% 
% % add fixed values
% if ~isempty(idFix)
%     x(idFix,:) = xFix;
% end
% 
% % add equivalues
% for i = 1:length(equivalue)
%     idx = equivalue{i};
%     x(idx,:) = repmat(x(idx(1),:),length(idx),1);
% end
% 
% % add binary constraints
% for i = 1:size(binary,1)
%     x(abs(binary(i,2)),:) = (binary(i,5)-binary(i,3)*x(abs(binary(i,1)),:))/binary(i,4);
% end

% % free memory used by HSL86
% if strcmpi(factor.alg,'hsl86') && nargout == 1
%     hsl_ma86_expert('destroy', factor.L);
% end

cprintf(iprn,'done %6.2f sec\n',toc(t1));

end