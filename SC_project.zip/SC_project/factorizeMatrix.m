function factor = factorizeMatrix(A,varargin)

% FACTORIZE factorizes matrix A using Cholesky, LDL or LU factorization. To be
% used in conjunction with FORWARDBACKWARDSOLVE
%
% USE:
% factor = factorizeMatrix(A,varargin)
%
% INPUTS:
% 'A' is the complete coefficient matrix
% 'varargin': optional arguments
%   * 'method': algorithm (optional). Options: 'chol' Cholesky, 'lu' LU factorization
%        'ldl' LDL' factorization or '' undetermined (default: '', automatic choice)
%   * 'verbose': verbose output. Available: 'y' yes, 'n' no (default: 'y')
%
% OUTPUTS:
% 'factor' struct with the following fields
%   * isreal: true (real matrix) false (complex matrix)
%   * issparse: true (sparse) false (full matrix)
%   * structure: 'diagonal','symmetric','hermitian','unsymmetric'
%   * method: factorization performed ('chol', 'ldl', 'lu')
%   * L: lower triangular part
%   * spd: symmetric positive definite
%   * D: block diagonal part (LDL only)
%   * U: upper triangular part (LU only)
%   * p: row permutation (and column CHOL/LDL)
%   * q: column permutation (LU only)
%   * S: scaling matrix (LDL only)
%   * R: row scaling (LU only)
%
% NOTES:
% - Matrix structure is checked by CHECKMATRIXSTRUCTURE.
% - When METHOD is undefined it is first checked if A is candidate for CHOL
%   (symmetric/hermitian and diagonally dominant), otherwise LU is used.
% - When CHOL fails and the matrix is real, LDL is used.
%
% VERSION:
% Date: 19.12.2009
% Copyright(C) 2009-2024: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
% 19.01.2011: added conditional print
% 03.03.2011: added check for diagonal matrices and solution
% 03.04.2012: added possibility ot provide preordering vector
% 12.04.2012: fixed text output  when user-defined preordering is provided
% 15.05.2012: added HSL86 algorithm for complex symmetric
% 15.05.2012: refurbished routine
% 28.09.2012: bug fix when HSL86 is not present
% 02.10.2012: added possibility of factorization of full matrices
% 10.12.2012: added permutation for full matrices
% 10.12.2012: added LDL factorization of full matrices
% 09.01.2013: bug fix on timing when HSL_MA86 is not available
% 17.01.2013: fixed bug on reordering of general full matrices
% 06.09.2013: bug fix for symmetrix complex dense matrices
% 26.03.2018: uses built-in dissect for nested dissection preordering
% 08.07.2024: refurbished routine (removed HSL solver)
% 25.09.2024: fixed bug with LDL and complex sparse matrices

% default inputs
method = '';
verbose = 'y';

% check varargin
for i = 1:2:length(varargin)
    vin = varargin{i};
    if any(strcmpi(vin,{'method','alg'}))
        method = varargin{i+1};
    elseif strcmpi(vin,'verbose')
        verbose = varargin{i+1};
    end
end

% initialize output
factor = struct(...
    'isreal',[],...
    'issparse',[],...
    'structure',[],...
    'method',[],...
    'L',[],...
    'p',[]);

% printing logical variable
iprn = strcmpi(verbose,'y');

% check algorithm
if ~sum(strcmpi(method,{'chol','ldl','lu',''}))
    error('Algorithm %s not available',method);
else
    factor.method = method;
end

% check real/complex
factor.isreal = isreal(A);

% check real/complex
factor.issparse = issparse(A);

% check for symmetry/hermitian
factor.structure = checkMatrixStructure(A,'threshold',1e-6,'verbose',verbose);

% diagonal matrix
if strcmpi(factor.structure,'diagonal')
    factor.L = inv(A);
    return
end

% check for approximate positive definiteness
if any(strcmpi(factor.structure,{'symmetric','hermitian'}))
    d = diag(A,0);   % extract diagonal
    factor.spd = all(real(d) > 0) && all(imag(d) == 0);
else
    factor.spd = false;
end

% algorithm choice
if isempty(factor.method) % automatic algorithm choice
    if factor.issparse
        if factor.spd
            factor.method = 'chol';
        else
            if strcmpi(factor.structure,'symmetric') && factor.isreal
                factor.method = 'ldl';
            else
                factor.method = 'lu';
            end
        end
    else
        if factor.spd
            factor.method = 'chol';
        else
            if any(strcmpi(factor.structure,{'symmetric','hermitian'}))
                factor.method = 'ldl';
            else
                factor.method = 'lu';
            end
        end
    end
end

% LL' factorization
if strcmpi(factor.method,'chol')
    t1 = tic;
    if factor.issparse
        % permutation
        t1 = tic;
        cprintf(iprn,'* METIS preordering... ');
        factor.p = dissect(A);
        cprintf(iprn,'done %6.2f sec\n',toc(t1));

        % sparse factorization
        cprintf(iprn,'* CHOL factorization with METIS preordering... ');
        [factor.L,p] = chol(A(factor.p,factor.p),'lower');
    else
        % full factorization
        cprintf(iprn,'* CHOL factorization of full matrix... ');
        [factor.L,p] = chol(A,'lower');
    end

    if p == 0
        cprintf(iprn,'done %6.2f sec\n',toc(t1));
        return
    else  % chol failed
        cprintf(iprn,'failed %6.2f sec\n',toc(t1));
        factor.spd = false;
        if factor.isreal
            factor.method = 'ldl';
        else
            factor.method = 'lu';
        end
    end
end

% LDL factorization
if strcmpi(factor.method,'ldl')
    t1 = tic;
    if factor.issparse
        cprintf(iprn,'* LDL factorization... ');
        [factor.L,factor.D,factor.p,factor.S] = ldl(A,'lower','vector');
    else
        cprintf(iprn,'* LDL factorization of full matrix... ');
        [factor.L,factor.D,factor.p] = ldl(A,'vector');
    end
    cprintf(iprn,'done %6.2f sec\n',toc(t1));
    return
end

% LU factorization
if strcmpi(factor.method,'lu')
    t1 = tic;
    if factor.issparse
        cprintf(iprn,'* LU factorization... ');
        [factor.L,factor.U,factor.p,factor.q,factor.R] = lu(A,'vector');
    else
        cprintf(iprn,'* LU factorization of full matrix... ');
        [factor.L,factor.U,factor.p] = lu(A,'vector');
    end
    cprintf(iprn,'done %6.2f sec\n',toc(t1));
end

end