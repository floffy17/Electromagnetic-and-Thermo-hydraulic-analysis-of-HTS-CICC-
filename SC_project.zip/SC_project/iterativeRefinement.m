function x = iterativeRefinement(A,b,x,factor,iterMAX,varargin)

% ITERATIVEREFINEMENT applies iterative refinement on the solution x of
% Ax = b providing the factorization
%
% USE:
% x = iterativeRefinement(A,b,x,factor,iterMAX)
%
% INPUTS:
% 'A': reduced (boundary conditins already applied) coefficient matrix
% 'b': reduced rhs
% 'x': approximate solution
% 'factor': struct with information on factorization (factors included)
% 'iterMAX': number of iterative refinement steps
% 'varargin': optional arguments
%   * 'verbose': verbose output. Available: 'y' yes, 'n' no (default: 'y')
%
% OUTPUTS:
% 'x': vector of unknowns after iterative refinement
%
% NOTE:
% Text output should be switched off
%
% VERSION:
% Date: 19.12.2009
% Copyright(C) 2009-2011: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
% 10.03.2011: added conditional print

% default inputs
verbose = 'y';

% check varargin
for i = 1:2:length(varargin)
    vin = varargin{i};
    if isequal(vin,'verbose')
        verbose = varargin{i+1};
    end
end

% printing logical variable
iprn = strcmpi(verbose,'y');

cprintf(iprn,'* iterative refinement... ');
t1 = tic;

for i = 1:iterMAX
    r = b - A*x;
    e = directSolve(A,r,[],[],'factor',factor,'iterMAX',0);
    x = x+e;
end

cprintf(iprn,'done %6.2f sec\n',toc(t1));