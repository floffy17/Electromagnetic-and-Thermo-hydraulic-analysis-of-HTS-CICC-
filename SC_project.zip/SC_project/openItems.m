function T = openItems(data)
% PART0_OPENITEMS  List every datum whose source is NOT the design tape itself
%   (HERMES/Faraday) or a hard project constraint (the brief). Three tiers:
%     OPEN     - genuinely missing, no data at all (e.g. true min Ic(77K,sf))
%     assumed  - a convention/engineering choice with no external data behind it
%     lab      - MISURATO da noi in laboratorio. Non e' un TODO: e' un dato
%                sperimentale, ma va dichiarato quali assunzioni servono per
%                interpretarlo (per la curva V-I: la distanza fra i tap).
%     faraday-ds - dal DATASET del fornitore (figshare 13708690). L'email di
%                Faraday Factory lo definisce "a representative sample of our
%                tape": stesso prodotto, ma UN campione, con copertura fino a
%                8 T / 15 K. Non e' un placeholder: e' un dato misurato, da
%                citare nel report con la sua copertura e la sua dispersione,
%                non un TODO da chiudere.
%
%   part0_openItems(data)        % prints a table
%   T = part0_openItems(data)    % also returns it as a cell table
%
%   Use this before trusting any final number: anything listed here needs a
%   sentence in the report explaining its provenance.

rows = {};
groups = {'op','tape','basis','lfx','joint','mech'};
for g = 1:numel(groups)
    grp = data.(groups{g});
    fn = fieldnames(grp);
    for i = 1:numel(fn)
        e = grp.(fn{i});
        if ~isstruct(e) || ~isfield(e,'src'), continue; end
        % n_T/n_B/n_tab sono la GRIGLIA della tabella n(T,B): stessa provenienza
        % di basis.n, gia' segnalata sopra come voce singola -> non ripetere
        % una tabella intera riga per riga qui.
        % Griglie e tabelle sono la stessa provenienza della voce sintetica
        % gia' elencata (basis.n, lfx.LFmin): non ripeterle riga per riga.
        if any(strcmp(fn{i}, {'n_T','n_B','n_tab','T','B','LFmin','angPeak_nominal'})), continue; end
        if any(strcmp(e.src,{'OPEN','assumed','faraday-ds','lab'}))
            v = e.val;
            if isnumeric(v) && isscalar(v), vs = num2str(v,'%.4g');
            elseif isnumeric(v),            vs = ['[' num2str(v(:).','%.4g ') ']'];
            else,                           vs = char(string(v)); end
            rows(end+1,:) = {[groups{g} '.' fn{i}], upper(e.src), vs, e.unit, e.note}; %#ok<AGROW>
        end
    end
end

fprintf('\n=== PART 0 - VOCI DA GIUSTIFICARE (OPEN / assumed / dataset fornitore) ===\n');
fprintf('%-22s %-9s %-14s %-8s %s\n','field','tag','value','unit','note');
fprintf('%s\n', repmat('-',1,105));
for k = 1:size(rows,1)
    fprintf('%-22s %-9s %-14s %-8s %s\n', rows{k,1}, rows{k,2}, rows{k,3}, rows{k,4}, rows{k,5});
end

% Messaggio finale COSTRUITO dallo stato reale (non testo fisso), cosi' non
% mente su cosa e' gia' risolto e cosa manca ancora.
fprintf('\n--- Stato delle voci chiave ---\n');
if strcmp(data.basis.Ic_ref77.src,'OPEN')
    fprintf(['  * basis.Ic_ref77 : ANCORA APERTO -> proxy %.0f A.\n' ...
        '                     Il metodo indicato dal fornitore e'' Ic = Ic_spec(77K,sf) * LF:\n' ...
        '                     serve quindi l''Ic(77K,sf) DEL NOSTRO nastro, non del campione\n' ...
        '                     del dataset. Il Data Book da'' solo il range 100-200 A.\n'], ...
        data.basis.Ic_ref77.val);
end
if strcmp(data.basis.E0.src,'faraday')
    fprintf('  * basis.E0       : CHIUSO -> 1 uV/cm confermato per iscritto dal fornitore.\n');
end
if strcmp(data.basis.n.src,'faraday-ds')
    fprintf(['  * basis.n        : dal dataset del fornitore (campione rappresentativo del\n' ...
        '                     nostro stesso nastro). n NON e'' costante: varia con T e B\n' ...
        '                     (tabella in basis.n_tab). Valore di progetto %.0f, sweep [%d %d].\n'], ...
        data.basis.n.val, data.basis.n_sweep.val(1), data.basis.n_sweep.val(2));
end
if isfield(data.basis,'n_lab77')
    fprintf(['  * basis.n_lab77  : CONTROLLO indipendente -> n = %.1f misurato in laboratorio\n' ...
        '                     a 76.9 K campo proprio, contro %.1f del dataset alle stesse\n' ...
        '                     condizioni (scarto %+.0f%%). Lo scarto e'' coerente col provino\n' ...
        '                     degradato (Ic ~1.9 A, Tc ~86 K), non e'' un errore di analisi.\n' ...
        '                     ATTENZIONE: dipende da basis.n_lab_Ltap, ASSUNTA a %.0f cm\n' ...
        '                     perche'' non dichiarata nei file di misura. Da recuperare.\n'], ...
        data.basis.n_lab77.val, 24.4, ...
        (data.basis.n_lab77.val-24.4)/24.4*100, data.basis.n_lab_Ltap.val*100);
end
if isfield(data,'lfx')
    fprintf(['  * lfx.spread     : DISPERSIONE DA DICHIARARE -> il fornitore indica %.0f-%.0f%%\n' ...
        '                     di deviazione standard sui lift factor da campione a campione.\n' ...
        '                     Va portata nel margine: con LF al -%.0f%% il margine si riduce.\n'], ...
        data.lfx.spread.val(1)*100, data.lfx.spread.val(2)*100, data.lfx.spread.val(1)*100);
    fprintf(['  * lfx.LFmin      : copertura fino a %.0f T e giu'' fino a %.0f K. Il punto di\n' ...
        '                     progetto (~15 T) e'' OLTRE: per l''alto campo resta il Data Book.\n'], ...
        max(data.lfx.B.val), min(data.lfx.T.val));
end

if nargout, T = rows; end
end