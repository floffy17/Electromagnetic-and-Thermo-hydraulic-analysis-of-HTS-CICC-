function data = dataAcquisition(verbose)
% PART0_DATAACQUISITION  Assemble and provenance-tag every input datum for the
%   HTS CICC double-pancake solenoid project (NELAHTP 2025/2026).
%
%   data = dataAcquisition()        % silent
%   data = dataAcquisition(true)    % prints a provenance report + sanity checks
%
%   This is the single source of truth for Part 0. Everything downstream
%   (Parts 1-5) pulls numbers from the returned struct so that no magic
%   constant is ever buried in a computational routine.
%
%   PROVENANCE TAGS (data.<field>.src):
%     'faraday'   verbatim from the HERMES Data Book (Faraday Factory, v.2025-07)
%     'brief'     from the project brief / operational-parameters slide
%     'assumed'   engineering assumption or convention (see .note for the ASSUMPTION-x id)
%     'literature'externally cited value
%     'OPEN'      NOT yet known -> placeholder standing in until instructor/Faraday reply
%
%   Fields carrying an 'OPEN' or 'assumed' tag are the ones to revisit when the
%   Faraday reply / instructor answers arrive; call openItems(data) for the list.
%
%   NELAHTP SC project - Part 0.  No dependency on the Freschi package here
%   (that starts in Part 2); Part 0 is pure data + the Ic evaluator.

if nargin < 1, verbose = false; end

data = struct();
data.meta.project   = 'HTS CICC double-pancake solenoid @ 15 T / 50 kA';
data.meta.datasheet = 'Faraday Factory HERMES - HTS Tape for Magnets, Data Book, version July 2025';
data.meta.generated = datestr(now,'yyyy-mm-dd HH:MM:SS');

% ------------------------------------------------------------------------
% 1. BRIEF / OPERATIONAL PARAMETERS  (project brief, "Operational parameters" slide)
% ------------------------------------------------------------------------
data.op.I_rated   = tag(50e3 ,'A'      ,'brief','Rated current (50 kA)');
data.op.dIdt      = tag(200  ,'A/s'    ,'brief','Ramp rate 0.2 kA/s');
data.op.t_ramp    = tag(data.op.I_rated.val/data.op.dIdt.val,'s','brief','0->50 kA ramp duration (=250 s)');
data.op.B_target  = tag(15   ,'T'      ,'brief','Max field on conductor incl. self-field');
data.op.dT_margin = tag(5    ,'K'      ,'brief','Required temperature margin (>= 5 K)');
data.op.ID_wind   = tag(1.0  ,'m'      ,'brief','Solenoid inner diameter');
data.op.H_max     = tag(1.5  ,'m'      ,'brief','Max solenoid height');
data.op.mdot_max  = tag(15e-3,'kg/s'   ,'brief','Max He mass flow rate (15 g/s)');
data.op.Tin_range = tag([4.5 50],'K'   ,'brief','Inlet temperature envelope');
data.op.pin_range = tag([5 20] ,'bar'  ,'brief','Inlet pressure envelope');

% ------------------------------------------------------------------------
% 2. HERMES TAPE - BASIC SPECIFICATIONS  (Data Book, "Basic Specifications")
% ------------------------------------------------------------------------
data.tape.width      = tag(4.0e-3 ,'m'    ,'faraday','Tape width 4.0 +/- 0.2 mm');
data.tape.width_tol  = tag(0.2e-3 ,'m'    ,'faraday','Width tolerance');
data.tape.len_range  = tag([100 700],'m'  ,'faraday','Tape length 100...700 m');
data.tape.Ic77_avg   = tag([100 200],'A'  ,'faraday','Average Ic @ 77K, self-field, 4mm');
data.tape.eps_crit   = tag(0.4e-2  ,'-'   ,'faraday','Critical deformation >= 0.4 %');
data.tape.dbend_crit = tag(10e-3   ,'m'   ,'faraday','Critical double-bend diameter <= 10 mm');
data.tape.sigma_uts  = tag(500e6   ,'Pa'  ,'faraday','Strength > 500 MPa');
data.tape.t_substr   = tag(40e-6   ,'m'   ,'faraday','Hastelloy C-276 substrate 35...45 um (nominal 40)');
data.tape.t_Ag_side  = tag(1e-6    ,'m'   ,'faraday','Silver stabilization 1 um back / (2 um surround per architecture)');
data.tape.t_Cu_side  = tag(5e-6    ,'m'   ,'faraday','Copper stabilization 5 um each side');

% Tape architecture layer stack (Data Book, "Tape Architecture"), top->bottom, per side as drawn.
% Total nominal thickness = sum below.
data.tape.layers = tag(struct( ...
    'Cu_top'   ,5.0e-6 , ...   % surround electroplating
    'Ag_top'   ,2.0e-6 , ...   % surround sputter
    'REBCO'    ,2.5e-6 , ...   % YBCO + Y2O3 nanoparticles, PLD
    'buffer'   ,0.1e-6 , ...   % IBAD/e-beam
    'Hastelloy',40e-6  , ...   % C-276
    'Ag_back'  ,1.0e-6 , ...   % sputter
    'Cu_back'  ,5.0e-6 ), ...  % electroplating
    'm','faraday','Layer stack; REBCO is YBCO+Y2O3-np (PLD) -> Tc ~ 92-93 K');
data.tape.t_total = tag( ...
    sum(structfun(@(x)x, data.tape.layers.val)) ,'m','faraday', ...
    'Total nominal tape thickness (sum of architecture layers)');
data.tape.t_REBCO = tag(2.5e-6,'m','faraday','Superconducting (YBCO) layer thickness');

% ------------------------------------------------------------------------
% 3. HERMES ELECTRIC / SUPERCONDUCTING PROPERTIES
% ------------------------------------------------------------------------
data.tape.rho_20C = tag(324e-3,'Ohm/m','faraday','Room-T resistivity 324 +/- 14 mOhm/m (886 samples)');

% --- Recommended Lift Factors table  (Data Book, "Recommended Lift Factors") ---
% LF(B,T) = min Ic(B,T) / min Ic(77K, self-field).  Rows = field [T], cols = temperature [K].
% RE-TRANSCRIBED (v2) from a clean, upright screenshot of the table. Corrections vs v1:
%   * removed a PHANTOM 0.70 T row that did not exist in the datasheet (it had shifted
%     several values and produced the spurious non-monotonicity at 50 K, 4-5 T);
%   * empty datasheet cells are stored as NaN (the sheet only measures high B at 4.2 & 20 K,
%     and leaves the 77.3 K column blank above 1 T) - NOT filled with invented numbers.
% Passes monotonicity in T (all rows) and in B >= 1 T (all cols), anchor LF(0,77.3)=1.00.
% NaN cells are handled by the interpolant via per-temperature 1-D interpolation (see
% buildIcEvaluator): each temperature column is interpolated over the fields where it is
% actually measured, so blanks never enter the numbers.
data.lf.T = tag([4.2 20 30 40 50 60 70 77.3],'K','faraday','Lift-factor table temperatures');
data.lf.B = tag([0.00 0.01 0.03 0.10 0.30 0.50 ...
                 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20].','T','faraday','Lift-factor table fields');
%           T=  4.2    20    30    40    50    60    70   77.3
data.lf.LF = tag([ ...
    15.9  11.7  9.1   6.8   5.0   3.3   1.9   1.00 ;   % 0.00 T
    NaN   11.7  9.1   6.8   4.9   3.3   1.9   0.91 ;   % 0.01 T
    NaN   11.6  9.0   6.7   4.8   3.2   1.7   0.74 ;   % 0.03 T
    NaN   11.3  8.6   6.2   4.3   2.6   1.2   0.46 ;   % 0.10 T
    NaN    9.8  7.0   4.7   3.0   1.8   0.76  0.27 ;   % 0.30 T
    11.5   7.3  5.8   3.9   2.5   1.4   0.58  0.22 ;   % 0.50 T
     9.3   6.1  4.2   2.8   1.8   1.0   0.40  0.12 ;   % 1 T
     7.0   4.3  2.9   2.0   1.3   0.69  0.26  NaN  ;   % 2 T
     5.8   3.5  2.4   1.6   1.0   0.54  0.19  NaN  ;   % 3 T
     5.0   3.0  2.1   1.4   0.88  0.46  0.15  NaN  ;   % 4 T
     4.4   2.6  1.8   1.2   0.76  0.38  0.11  NaN  ;   % 5 T
     4.0   2.3  1.7   1.1   0.68  0.33  NaN   NaN  ;   % 6 T
     3.7   2.1  1.5   1.0   0.60  0.28  NaN   NaN  ;   % 7 T
     3.4   1.9  1.3   0.89  0.53  0.24  NaN   NaN  ;   % 8 T
     3.2   1.8  NaN   NaN   NaN   NaN   NaN   NaN  ;   % 9 T
     3.0   1.7  NaN   NaN   NaN   NaN   NaN   NaN  ;   % 10 T
     2.7   1.5  NaN   NaN   NaN   NaN   NaN   NaN  ;   % 12 T
     2.5   1.4  NaN   NaN   NaN   NaN   NaN   NaN  ;   % 14 T
     2.3   1.3  NaN   NaN   NaN   NaN   NaN   NaN  ;   % 16 T
     2.1   1.2  NaN   NaN   NaN   NaN   NaN   NaN  ;   % 18 T
     2.0   1.1  NaN   NaN   NaN   NaN   NaN   NaN  ], ...% 20 T
     '-','faraday','LF(B,T) = minIc(B,T)/minIc(77K,sf); rows=B, cols=T; NaN = datasheet blank');

% ------------------------------------------------------------------------
% 4. DESIGN-BASIS CHOICES / CONVENTIONS  (assumptions - revisit on Faraday reply)
% ------------------------------------------------------------------------
% ASSUMPTION-2 (updated): the LF table is normalised to *min* Ic(77K,sf), whose
%   absolute value is NOT printed in the Data Book. Basic-Specs gives only the
%   *average* range 100-200 A. We adopt the conservative floor of that range as a
%   proxy for the (unknown) min, pending Faraday's answer -> OPEN.
data.basis.Ic_ref77 = tag(100 ,'A','OPEN', ...
    ['Reference min Ic(77K,sf) anchoring the LF table. Proxy = low end of the ' ...
     'average range; true min not in datasheet. ASSUMPTION-2 / awaiting Faraday.']);

% E0 criterion - not stated by Faraday. Convention adopted.  ASSUMPTION / OPEN-1.
% E0 CONFERMATO DAL FORNITORE (email Faraday Factory): "The criterion is 1 uV/cm".
% Coincide con quanto ricavabile dal dataset (Vc = 0.5 uV su prese a 5 mm =
% 1e-4 V/m) e con la convenzione IEC 61788 che avevamo assunto -> OPEN-1 CHIUSO.
data.basis.E0 = tag(1e-4,'V/m','faraday', ...
    'Criterio Ic = 1 uV/cm = 1e-4 V/m. Confermato per iscritto dal fornitore (email Faraday Factory) e coerente col dataset (Vc=0.5uV/5mm).');

% n index - not in datasheet. Literature standing value + sweep.  ASSUMPTION-6.
% --- ESPONENTE n DELLA POWER LAW: ora da DATI MISURATI --------------------
% Fonte: dataset figshare 13708690 (misure gen. 2021, campione SOX021, nastro
% 4 mm inciso a ponte 1x5 mm). Il dataset fornisce n gia' fittato punto per
% punto secondo V = V0 + V1*I + Vc*(I/Ic)^n.
%
% PROVENIENZA (chiarita dall'email del fornitore): il dataset NON e' di un
% produttore terzo. Faraday Factory lo indica come "a very detailed dataset of
% Ic values for A REPRESENTATIVE SAMPLE OF OUR TAPE". E' quindi il campione di
% riferimento del fornitore stesso -> tag 'faraday-ds' (dataset), da distinguere
% da 'faraday' (Data Book) solo per il tipo di statistica dietro i numeri:
%   'faraday'    = Data Book: lift factor MEDIATI su molti campioni (a 20 K/20 T
%                  su oltre 10.000 misure), copertura fino a 20 T e 4.2 K;
%   'faraday-ds' = dataset: UN campione rappresentativo, risoluzione angolare
%                  completa e valori di n, ma copertura fino a 8 T e 15 K.
% I valori qui sotto sono presi ALL'ANGOLO DI Ic MINIMO, coerentemente con la
% convenzione usata per i lift factor (worst case sull'angolo).
%
% COERENZA VERIFICATA: confrontando i lift factor delle due fonti dove si
% sovrappongono (0-8 T, 20-77 K), l'accordo e' entro il 5% su 75 punti su 77
% (scarto medio 1.2%). Coerente col fatto che descrivono lo stesso prodotto.
%
% COPERTURA: il dataset arriva a 8 T e scende a 15 K; il punto di progetto
% (~15 T, ~10 K) e' FUORI griglia. n pero' si appiattisce ad alto campo
% (a 15 K passa da 30.8 a 1 T a 27.6 a 8 T), quindi l'estrapolazione e' stabile.
data.basis.n_T = tag([15 20 25 30 40 50 60 70 77.5],'K','faraday-ds', ...
    'Temperature della tabella n(T,B)');
data.basis.n_B = tag([0 0.5 1 2 3 5 7 8].','T','faraday-ds', ...
    'Campi della tabella n(T,B)');
%                       T=  15    20    25    30    40    50    60    70   77.5
data.basis.n_tab = tag([ ...
    52.9  41.3  33.6  29.4  26.4  25.4  25.9  25.8  24.6 ;   % 0.0 T
    33.5  28.2  23.2  20.2  18.3  17.5  16.7  14.7  12.5 ;   % 0.5 T
    30.8  25.2  21.5  19.7  18.4  17.7  16.0  13.6  10.3 ;   % 1.0 T
    28.1  24.1  21.6  19.9  18.2  16.9  15.6  12.2   7.8 ;   % 2.0 T
    26.9  24.0  20.9  19.3  18.2  16.9  14.1  10.4   5.7 ;   % 3.0 T
    27.2  22.3  19.7  20.2  18.2  15.7  12.3   8.2   3.0 ;   % 5.0 T
    28.5  23.6  20.8  17.6  17.2  14.5  10.7   5.8   2.2 ;   % 7.0 T
    27.6  22.2  19.7  17.8  16.2  12.6   9.7   4.8   1.5 ], ...% 8.0 T
    '-','faraday-ds','n(B,T) all''angolo di Ic minimo; righe=B, colonne=T');

% Valore di lavoro al punto di progetto (15 T, 10 K), ESTRAPOLATO dalla tabella:
% a 15 K l'estrapolazione logaritmica su B>=3 T da' n ~ 28.8; a 20 K ~ 21.9.
% A 10 K (sotto la griglia) n sarebbe ancora piu' alto. Si adotta un valore
% conservativo nel mezzo, con sweep sulla banda misurata.
data.basis.n      = tag(25,'-','faraday-ds', ...
    'n al punto di progetto (~15 T, 10 K), estrapolato dalla tabella del dataset Faraday. Prima era 20 da letteratura.');
data.basis.n_sweep= tag([20 30],'-','faraday-ds', ...
    'Sweep di sensibilita'' su n, coerente con la dispersione misurata ad alto campo.');

% ------------------------------------------------------------------------
% n - MISURA DI LABORATORIO (gruppo 9). CONTROLLO, non base di progetto.
% ------------------------------------------------------------------------
% Caratterizzazione V-I in azoto liquido su provino, a 76.92 K, campo proprio
% e con campo applicato (valore di B non registrato nei file).
%
% ANALISI: sottrazione dell'offset (~2.1e-7 V, termoelettrico e di
% amplificatore; senza sottrarlo i primi punti danno n negativo), poi
% regressione di log(V-V_off) su log(I) nella finestra [E0/3, 3*E0] attorno
% al criterio. NON si e' fittata tutta la curva: l'esponente locale scende
% con continuita' da ~24 appena sopra la transizione a ~5.9 alla corrente
% massima, perche' la power law e' un'approssimazione LOCALE valida attorno
% a Ic.
%
% PERCHE' NON E' LA BASE DI PROGETTO, per tre ragioni indipendenti:
%
%  1. MANCA LA DISTANZA FRA I TAP DI TENSIONE. Il criterio di Ic e' un campo
%     elettrico (1 uV/cm), quindi senza quella distanza non si sa a quale
%     tensione corrisponda, e poiche' l'esponente locale varia lungo la curva
%     il risultato dipende dall'assunzione:
%        L_tap 0.5 cm -> n = 18.1 | 1 cm -> 16.9 | 2 cm -> 15.5
%        L_tap 5 cm   -> n = 12.4 | 10 cm -> 10.4
%     Il dataset del fornitore invece la DICHIARA (5 mm, con Vc = 0.5 uV,
%     cioe' esattamente 1 uV/cm): e' interpretabile senza assunzioni.
%
%  2. FIT MENO COMPLETO. Il dataset fitta V = V0 + V1*I + Vc*(I/Ic)^n, con un
%     termine LINEARE che descrive la conduzione ohmica parassita. Sui dati di
%     laboratorio si e' potuto togliere solo l'offset costante, e il termine
%     lineare residuo distorce la pendenza verso il basso.
%
%  3. IL PROVINO ERA DEGRADATO. Dalle stesse misure: Ic(77 K, campo proprio)
%     ~ 1.9 A contro i ~150 A attesi da un nastro da 4 mm, e la curva di
%     raffreddamento mostra transizione a ~86 K con resistenza nulla a ~83 K,
%     contro i ~92 K del REBCO integro. Un provino degradato ha transizione
%     meno ripida, quindi n piu' basso: lo scarto col dataset (-31% a parita'
%     di condizioni) e' COERENTE col degrado, non un errore di analisi.
%
% VALORE DELLA MISURA: conferma la procedura e l'ordine di grandezza, ed e' un
% dato sperimentale proprio da citare nel report. Non sostituisce la tabella.
data.basis.n_lab77 = tag(16.9,'-','lab', ...
    ['n @ Ic misurato in laboratorio a 76.9 K campo proprio, per L_tap = 1 cm ' ...
     'ASSUNTA (non dichiarata nei file). Sigma del fit 0.8. Confronto col ' ...
     'dataset alle stesse condizioni: 24.4, cioe'' -31%. Provino degradato ' ...
     '(Ic ~1.9 A contro ~150 A nominali, Tc ~86 K contro ~92 K). CONTROLLO.']);
data.basis.n_lab77_B = tag(11.3,'-','lab', ...
    ['n @ Ic in laboratorio con campo applicato (valore di B non registrato). ' ...
     'Il rapporto rispetto al campo proprio vale 0.68 +/- 0.03 per OGNI L_tap ' ...
     'assunta: che n cali col campo e'' quindi un risultato solido della misura, ' ...
     'indipendente dalla metadata mancante.']);
data.basis.n_lab_Ltap = tag(0.01,'m','assumed', ...
    ['Distanza fra i tap di tensione assunta per interpretare le misure di ' ...
     'laboratorio. NON dichiarata nei file: da recuperare dal quaderno di ' ...
     'laboratorio o rimisurare sul provino. Sposta n fra 10.4 e 18.1.']);

% Tc - YBCO (confirmed by datasheet chemistry).  ASSUMPTION-1 (refined).
data.basis.Tc = tag(92,'K','literature', ...
    'YBCO Tc ~ 92 K (datasheet REBCO = YBCO+Y2O3-np). ASSUMPTION-1; may be released as fit param.');

% Field-angle convention bridge.  Faraday plots: angle from c-axis (Bperp/c = 0/180 deg).
%   Freschi s6: theta from tape PLANE (theta=0 -> B parallel, theta=+/-90 -> B perp).
%   Relationship:  theta_Freschi = angle_Faraday - 90 deg.  ASSUMPTION-5.
data.basis.angleConv = tag('theta_Freschi = angleFaraday - 90 deg','-','assumed', ...
    ['Faraday angle measured from c-axis (0/180 deg = B perp tape). ' ...
     'LF *table* is min over angle (worst-case), so no extra angle assumption needed for the table.']);

% ------------------------------------------------------------------------
% 5. JOINTS  (Data Book, "Joints") - resolves the earlier open question on joints
% ------------------------------------------------------------------------
data.joint.R_avg     = tag(8.9e-9 ,'Ohm'   ,'faraday','Lap joint (PbSn), avg resistance, 75 mm x 4 mm');
data.joint.R_area    = tag(26.7e-9,'Ohm*cm2','faraday','Area-normalised joint resistance (avg)');
data.joint.overlap   = tag(75e-3  ,'m'     ,'faraday','Lap-joint overlap length');

% ------------------------------------------------------------------------
% 6. MECHANICAL (extra Data Book values useful in Part 3)
% ------------------------------------------------------------------------
data.mech.delam_avg = tag(71e6,'Pa','faraday','Delamination strength avg ~71 MPa (Weibull dist.)');

% ------------------------------------------------------------------------
% 7. BUILD THE Ic EVALUATOR (design basis) + convenience handles
% ------------------------------------------------------------------------
% ========================================================================
%  SCELTA DELLA BASE DATI PER Ic(T,B)  --  DECISIONE ESPLICITA
% ========================================================================
%  Le due fonti Faraday NON sono intercambiabili. Confronto sulle condizioni
%  di progetto (B_pk ~ 15 T, T_op ~ 6 K):
%
%                        Data Book        dataset figshare
%    campo massimo         20 T                 8 T
%    T minima             4.2 K                15 K
%    statistica    >10.000 misure/punto     1 campione
%    angoli        solo 77K e 20K       55 angoli, tutte le T
%    esponente n         assente              presente
%    COPRE 15 T ?          SI                   NO
%
%  >>> BASE DI PROGETTO PER Ic(T,B) = DATA BOOK HERMES, unica fonte. <<<
%  Il dataset figshare NON puo' esserlo: si ferma a 8 T, cioe' sotto il punto
%  di progetto. Non c'e' quindi nessuna "fusione" delle due tabelle: data.Ic
%  usa ESCLUSIVAMENTE la tabella del Data Book.
%
%  Il dataset resta usato per DUE cose che sono grandezze FISICHE DIVERSE da
%  Ic(T,B), quindi non costituiscono un mescolamento di basi dati:
%    (a) n(T,B)  - il Data Book non lo fornisce affatto;
%    (b) validazione incrociata dei lift factor nella zona di sovrapposizione
%        0-8 T (accordo entro il 5% su 75 punti su 77).
%  Le tabelle qui sotto (data.lfx) sono quindi di SOLA VALIDAZIONE E
%  DOCUMENTAZIONE: nessuna funzione di progetto le legge.
% ------------------------------------------------------------------------
%  Metodologia dei lift factor indicata dall'email del fornitore
% ------------------------------------------------------------------------
%  Procedura indicata da Faraday Factory:
%    1) LF(T,B,angolo) = Ic(T,B,angolo) / Ic(77.5 K, 0 T)
%       con Ic(77.5 K, 0 T) = 508 A/cm per il campione del dataset;
%    2) per il progetto di magneti usare il MINIMO di LF su TUTTI gli angoli
%       ("the safest approach is to use... the minimum Ic (lift-factor) for
%        specific B, T for all angles of magnetic field");
%    3) Ic del nastro di interesse = Ic_spec(77 K, s.f.) * LF.
%  Il punto 3 e' esattamente il modello gia' usato: Ic = Ic_ref77 * LF.
data.lfx.USED_FOR_DESIGN = tag(false,'-','faraday-ds', ...
    'FALSE: le tabelle lfx sono di sola validazione. La base di progetto per Ic(T,B) e'' il Data Book (data.lf).');
data.lfx.ref_Acm = tag(508,'A/cm','faraday-ds', ...
    'Ic(77.5K, 0T) del campione del dataset: riferimento di normalizzazione dei LF (dall''email).');

%  DISPERSIONE STATISTICA (dall'email): "Typical standard deviation for the
%  statistical spread of lift-factors is about 15-20%". NON e' un errore da
%  eliminare: e' la variabilita' reale da nastro a nastro, e va portata nel
%  margine di progetto. Con LF -15% il margine di temperatura si riduce.
data.lfx.spread = tag([0.15 0.20],'-','faraday-ds', ...
    'Deviazione standard tipica dei lift factor da campione a campione (dall''email). Usare come banda di incertezza sul progetto.');

data.lfx.T = tag([15 20 25 30 35 40 45 50 55 60 65 70 77.5],'K','faraday-ds', ...
    'Temperature della griglia del dataset');
data.lfx.B = tag([0 0.01 0.05 0.1 0.3 0.5 1 2 3 5 7 8].','T','faraday-ds', ...
    'Campi della griglia del dataset (max 8 T: sotto il punto di progetto)');
%                    T=  15      20      25      30      35      40      45      50      55      60      65      70     77.5
data.lfx.LFmin = tag([ ...
   12.9969 11.7183 10.3757  9.1021  7.9101  6.8391  5.8590  4.9591  4.1225  3.3472  2.6115  1.9323  1.0000 ;   % 0.00 T
   12.9941 11.7183 10.3745  9.0930  7.9015  6.8204  5.8415  4.9437  4.0980  3.3102  2.5749  1.8816  0.9180 ;   % 0.01 T
   12.9056 11.6373 10.2553  8.9607  7.7445  6.6324  5.6151  4.6943  3.8295  3.0087  2.2469  1.5279  0.6186 ;   % 0.05 T
   12.6853 11.3623  9.9872  8.6373  7.3887  6.2651  5.2209  4.2687  3.4070  2.6096  1.8761  1.2292  0.4620 ;   % 0.10 T
   11.1825  9.7880  8.3257  6.9882  5.7646  4.7423  3.8442  3.0439  2.3696  1.7618  1.2232  0.7644  0.2677 ;   % 0.30 T
    9.6379  8.2746  6.9270  5.7472  4.7140  3.8478  3.1070  2.4555  1.8963  1.3936  0.9557  0.5897  0.1989 ;   % 0.50 T
    7.1853  6.0814  5.0488  4.1932  3.4384  2.8039  2.2608  1.7819  1.3605  0.9904  0.6697  0.4044  0.1227 ;   % 1.00 T
    5.0661  4.2858  3.5641  2.9559  2.4237  1.9817  1.6035  1.2596  0.9587  0.6912  0.4585  0.2648  0.0614 ;   % 2.00 T
    4.0869  3.4648  2.8729  2.3798  1.9599  1.6151  1.3021  1.0212  0.7708  0.5454  0.3544  0.1937  0.0309 ;   % 3.00 T
    3.0899  2.5917  2.1513  1.8017  1.4803  1.2195  0.9790  0.7610  0.5622  0.3832  0.2317  0.1080  0.0047 ;   % 5.00 T
    2.5309  2.1192  1.7539  1.4654  1.2075  0.9837  0.7838  0.6007  0.4274  0.2783  0.1522  0.0557  0.0006 ;   % 7.00 T
    2.3214  1.9388  1.6113  1.3480  1.1013  0.8973  0.7054  0.5271  0.3721  0.2366  0.1218  0.0374  0.0004 ], ...% 8.00 T
    '-','faraday-ds','LF_min(B,T) = min su TUTTI gli angoli di Ic / Ic(77.5K,0T); righe=B, colonne=T');

%  OFF-SHIFT ANGOLARE (dall'email): nominalmente 0/180 deg = B perpendicolare
%  al nastro (B // asse c) e 90/270 deg = B parallelo (B // ab). In realta'
%  l'asse c del REBCO e' inclinato di qualche grado rispetto alla normale, per
%  le peculiarita' della crescita IBAD-MgO, quindi il MASSIMO di Ic e' spostato
%  di alcuni gradi da 90/270, e lo spostamento dipende da T e B.
%  Misurato su questo dataset: shift da -2.5 a -14.5 deg (medio -6.3 deg),
%  piu' marcato a basso campo.
%  RILEVANZA PER IL PROGETTO: usiamo il MINIMO su angolo, che sta vicino a
%  0/180 deg, non al picco -> l'off-shift NON sposta il valore di progetto.
%  Va pero' documentato, perche' invalida un eventuale modello analitico
%  Ic(theta) centrato esattamente su 90 deg (p.es. quello su [Freschi s6]).
data.lfx.angPeak_nominal = tag(90,'deg','faraday-ds','Angolo nominale del picco di Ic (B // ab)');
data.lfx.angPeak_shift   = tag([-14.5 -2.5],'deg','faraday-ds', ...
    'Intervallo misurato dello shift del picco di Ic rispetto a 90 deg (T-B dipendente, dall''email + dataset).');

data.Ic = buildIcEvaluator(data);

% --- evaluatore n(T,B) dalla tabella SuperOx (interp bilineare, clamp ai bordi)
data.nEJ = buildNevaluator(data);

% ------------------------------------------------------------------------
% 8. REPORT
% ------------------------------------------------------------------------
if verbose
    part0_report(data);
    part0_sanityChecks(data);
end
end % ===================== end main =====================


% ========================================================================
function s = tag(val,unit,src,note)
% Wrap a datum with unit + provenance so nothing travels un-attributed.
s = struct('val',val,'unit',unit,'src',src,'note',note);
end


% ========================================================================
function nf = buildNevaluator(data)
% Evaluatore n(T,B) dalla tabella SuperOx. Interpolazione bilineare con clamp
% ai bordi della griglia: il punto di progetto (~15 T) e' oltre gli 8 T misurati,
% ma n si appiattisce ad alto campo, quindi il clamp e' una scelta stabile e
% leggermente CONSERVATIVA (n reale a 15 T e' poco piu' basso del valore a 8 T
% alle temperature alte, poco piu' alto a quelle basse).
Tg = data.basis.n_T.val(:);
Bg = data.basis.n_B.val(:);
NT = data.basis.n_tab.val;          % righe = B, colonne = T
    function v = evalN(T,B)
        Bc = min(max(abs(B), min(Bg)), max(Bg));
        Tc = min(max(T,      min(Tg)), max(Tg));
        jb = find(Bg<=Bc,1,'last'); jb2 = min(jb+1, numel(Bg));
        jt = find(Tg<=Tc,1,'last'); jt2 = min(jt+1, numel(Tg));
        wb = 0; if jb2>jb, wb = (Bc-Bg(jb))/(Bg(jb2)-Bg(jb)); end
        wt = 0; if jt2>jt, wt = (Tc-Tg(jt))/(Tg(jt2)-Tg(jt)); end
        v = (1-wb)*(1-wt)*NT(jb,jt) + wb*(1-wt)*NT(jb2,jt) + ...
            (1-wb)*wt   *NT(jb,jt2) + wb*wt   *NT(jb2,jt2);
    end
nf.eval    = @evalN;
nf.inGrid  = @(B,T) (abs(B)>=min(Bg) & abs(B)<=max(Bg) & T>=min(Tg) & T<=max(Tg));
nf.Bgrid   = Bg;  nf.Tgrid = Tg;  nf.table = NT;
end

% ========================================================================
function Ic = buildIcEvaluator(data)
% Design-basis empirical evaluator:  Ic(T,B) = Ic_ref77 * LF(B,T)
% Interpolation: linear in B, linear in T, on log(LF) (LF spans ~2.5 decades and
% is quasi-exponential in T). Angle: the LF table is already the worst-case-over-angle
% envelope, so Ic(T,B,theta) := Ic(T,B) for the table-based design basis (ASSUMPTION-5).
%
% Returns a struct of function handles:
%   Ic.LF(B,T)         -> lift factor (scalar/vector, extrapolation guarded)
%   Ic.eval(T,B[,th])  -> critical current [A]  (theta ignored: table is worst-case)
%   Ic.Tcs(Itape,B[,th])-> current-sharing temperature [K]
%   Ic.inGrid(B,T)     -> logical, is (B,T) inside the tabulated envelope

Bt = data.lf.B.val(:);          % Nb x 1  fields
Tt = data.lf.T.val(:);          % NT x 1  temperatures
LF = data.lf.LF.val;            % Nb x NT (may contain NaN = datasheet blanks)
Iref = data.basis.Ic_ref77.val; % A

Ic.Bgrid = Bt;  Ic.Tgrid = Tt;  Ic.Iref = Iref;  Ic.LFtable = LF;

% For each temperature column, keep the B range over which it is actually measured.
% (High B is only measured at 4.2 & 20 K; the 77.3 K column stops at 1 T; etc.)
NT = numel(Tt);
Bmax_col = nan(NT,1);  Bmin_col = nan(NT,1);
for j = 1:NT
    m = ~isnan(LF(:,j));
    Bmin_col(j) = min(Bt(m));
    Bmax_col(j) = max(Bt(m));
end
% A query (B,T) is "in grid" if T is within [min,max] tabulated temperatures AND B is
% within the measured B-range of BOTH temperature columns that bracket T.
    function tf = inGridFun(B,T)
        B = abs(B(:));  T = T(:);
        tf = false(size(B));
        for q = 1:numel(B)
            if T(q) < min(Tt) || T(q) > max(Tt), continue; end
            % bracketing temperature columns
            jhi = find(Tt >= T(q), 1, 'first');
            jlo = find(Tt <= T(q), 1, 'last');
            bcap = min(Bmax_col(jlo), Bmax_col(jhi));   % conservative: covered by both
            bflr = max(Bmin_col(jlo), Bmin_col(jhi));
            tf(q) = (B(q) >= bflr) && (B(q) <= bcap);
        end
    end
Ic.inGrid = @inGridFun;

% NaN-aware LF interpolation: for each query, interpolate log(LF) in B within each
% bracketing temperature column (using only that column's measured points), then
% interpolate linearly in T between the two column results. Log-space because LF spans
% ~2.5 decades and is quasi-exponential in T.
    function lf = LFfun(B,T)
        B = abs(B);  szin = size(B);
        Bv = B(:);   Tv = T(:);
        if isscalar(Tv) && ~isscalar(Bv), Tv = repmat(Tv,size(Bv)); end
        if isscalar(Bv) && ~isscalar(Tv), Bv = repmat(Bv,size(Tv)); end
        lf = nan(size(Bv));
        for q = 1:numel(Bv)
            Bq = Bv(q);  Tq = Tv(q);
            % clamp T into tabulated range (design point is inside; clamp only guards edges)
            Tc = min(max(Tq, min(Tt)), max(Tt));
            jhi = find(Tt >= Tc, 1, 'first');
            jlo = find(Tt <= Tc, 1, 'last');
            lyj = zeros(1,2);  jj = [jlo jhi];
            for k = 1:2
                col = LF(:,jj(k));  m = ~isnan(col);
                Bm = Bt(m);  Lm = log(col(m));
                Bcq = min(max(Bq, min(Bm)), max(Bm));   % clamp B into this column's range
                %  QUESTO WARNING ERA A RISCHIO ALLUVIONE: data.Ic.eval e' richiamata
                %  per ogni arco della mesh, per ogni iterazione di Picard, per ogni
                %  passo temporale del DAE (Step 4.4) - un progetto con Ic al di fuori
                %  del range misurato per gran parte del conduttore poteva stampare
                %  questo avviso CENTINAIA di volte identico, spingendo fuori dal
                %  buffer della command window tutto cio' che veniva stampato prima
                %  (incluse le sezioni piu' importanti, come la 3.3 con il margine).
                %
                %  NON si usa 'persistent' qui: LFfun e' una funzione ANNIDATA dentro
                %  buildIcEvaluator, e MATLAB tratta le persistent nelle funzioni
                %  annidate in modo diverso da quelle in funzioni normali - richiamare
                %  buildIcEvaluator piu' volte nella stessa sessione (come fa
                %  dataAcquisition, prima nei sanity check e poi nel resto del main)
                %  genera l'errore "Variable ... exists in the current workspace" alla
                %  ridichiarazione. Si usa invece lo STATO DEL WARNING stesso (on/off
                %  per identificativo), che vive nel motore dei warning di MATLAB, non
                %  nel workspace della funzione: si stampa solo se l'identificativo e'
                %  ancora 'on', poi lo si spegne. La sezione 3.3b del main mostra gia'
                %  quanto del conduttore e' interessato (profilo di Ic lungo tutto il
                %  DP): quella tabella, non il conteggio dei warning, e' il modo giusto
                %  per giudicare quanto pesa l'estrapolazione.
                if Bq > max(Bm) || Bq < min(Bm)
                    wst = warning('query', 'part0:LFextrapolation');
                    if strcmp(wst.state, 'on')
                        warning('part0:LFextrapolation', ...
                            ['Query B=%.3g T outside measured range [%.3g,%.3g] T at T=%.1f K - ' ...
                             'clamped. (Questo avviso si ripete per molte altre chiamate nello ' ...
                             'stesso run: le successive sono SOPPRESSE per non inondare la command ' ...
                             'window. Vedi Step 3.3b nel main per il quadro completo di quanto del ' ...
                             'conduttore e'' interessato.)'], ...
                            Bq, min(Bm), max(Bm), Tt(jj(k)));
                        warning('off', 'part0:LFextrapolation');
                    end
                end
                lyj(k) = interp1(Bm, Lm, Bcq, 'linear');
            end
            if jlo == jhi
                lf(q) = exp(lyj(1));
            else
                w = (Tc - Tt(jlo)) / (Tt(jhi) - Tt(jlo));
                lf(q) = exp((1-w)*lyj(1) + w*lyj(2));
            end
        end
        lf = reshape(lf, szin);
    end
Ic.LF = @LFfun;

% Critical current [A]. theta accepted for interface compatibility but unused (table = worst case).
Ic.eval = @(T,B,varargin) Iref .* LFfun(B,T);

% Current-sharing temperature: solve Ic(Tcs,B) = Itape for Tcs.
% IMPORTANT: restrict the search to the T-range where B is GENUINELY measured
% (contiguous from the coldest tabulated T) - do NOT let bisection wander into
% temperatures where this field was never measured, where LFfun would silently
% substitute a clamped (lower-field) proxy and bias the result. This also stops
% the warning spam: LFfun's per-query extrapolation warning no longer fires
% during a normal, in-range Tcs search.
    function [Tcs, status] = TcsFun(Itape,B,varargin)
        % status: 'certified' = radice risolta DENTRO le temperature realmente
        %                       misurate a quel campo -> valore affidabile;
        %         'lowerBound'= Ic e' ancora > Itape alla T piu' calda misurata:
        %                       la vera T_cs sta OLTRE i dati. Si restituisce il
        %                       limite come LIMITE INFERIORE, non come valore;
        %         'coldCap'   = Ic e' gia' < Itape alla T piu' fredda misurata;
        %         'noData'    = nessuna T misurata a quel campo.
        % Il chiamante DEVE distinguere: un margine calcolato da 'lowerBound' e'
        % un limite inferiore, non una misura.
        validMask = arrayfun(@(t) Ic.inGrid(B,t), Tt);
        if ~any(validMask)
            Tcs = NaN; status = 'noData'; return
        end
        Tvalid = Tt(validMask);
        Tlo = min(Tvalid);  Thi = max(Tvalid);

        f = @(T) Ic.eval(T,B) - Itape;      % decrescente in T
        flo = f(Tlo); fhi = f(Thi);
        if flo <= 0
            Tcs = Tlo; status = 'coldCap'; return
        elseif fhi >= 0
            % La vera T_cs eccede la T piu' calda misurata a questo campo.
            % NESSUN warning qui: e' una condizione normale a basso campo, e
            % stamparla per ogni nodo del profilo genererebbe centinaia di
            % righe. Il chiamante la rileva dal flag 'status'.
            Tcs = Thi; status = 'lowerBound'; return
        end
        for it = 1:60
            Tm = 0.5*(Tlo+Thi);
            if f(Tm) > 0, Tlo = Tm; else, Thi = Tm; end
            if (Thi-Tlo) < 1e-4, break; end
        end
        Tcs = 0.5*(Tlo+Thi);  status = 'certified';
    end

% Copertura in temperatura effettivamente misurata a un dato campo: serve a
% sapere a priori entro quale finestra T_cs puo' essere certificata.
    function [Tmin,Tmax] = TrangeFun(B)
        vm = arrayfun(@(t) Ic.inGrid(B,t), Tt);
        if ~any(vm), Tmin = NaN; Tmax = NaN; else, Tmin = min(Tt(vm)); Tmax = max(Tt(vm)); end
    end
Ic.Trange = @TrangeFun;
Ic.Tcs = @TcsFun;
end


% ========================================================================
function part0_report(data)
fprintf('\n============================================================\n');
fprintf(' PART 0 - DATA ACQUISITION REPORT\n');
fprintf(' %s\n', data.meta.datasheet);
fprintf(' generated %s\n', data.meta.generated);
fprintf('============================================================\n');
printGroup('OPERATIONAL (brief)', data.op);
printGroup('TAPE - basic/architecture', data.tape);
printGroup('DESIGN BASIS (assumptions/open)', data.basis);
printGroup('JOINTS', data.joint);
printGroup('MECHANICAL', data.mech);
fprintf('\n-- Ic evaluator built: Ic.eval(T,B), Ic.Tcs(Itape,B), Ic.LF(B,T)\n');
end

function printGroup(title, g)
fprintf('\n--- %s ---\n', title);
fn = fieldnames(g);
for i = 1:numel(fn)
    e = g.(fn{i});
    if ~isstruct(e) || ~isfield(e,'val'), continue; end
    v = e.val;
    if isnumeric(v) && isscalar(v),      vs = num2str(v,'%.4g');
    elseif isnumeric(v) && isvector(v),  vs = ['[' num2str(v(:).','%.4g ') ']'];
    elseif isstruct(v),                  vs = '(struct)';
    else,                                vs = char(string(v));
    end
    flag = '';
    if strcmp(e.src,'OPEN'),   flag = '  <<< OPEN';
    elseif strcmp(e.src,'assumed'), flag = '  (assumed)';
    end
    fprintf('  %-12s = %-16s [%-4s] %-10s  %s%s\n', fn{i}, vs, e.unit, e.src, e.note, flag);
end
end


% ========================================================================
function part0_sanityChecks(data)
fprintf('\n--- SANITY CHECKS ---\n');
Ic = data.Ic;  LF = data.lf.LF.val;  Bt = data.lf.B.val;  Tt = data.lf.T.val;

% (1) anchor
a = LF(1,end);  ok = abs(a-1.0)<1e-9;
fprintf('  [%s] LF(0 T, 77.3 K) = %.3f (expect 1.000)\n', pf(ok), a);

% (2) monotone decreasing in T for every field row (ignore NaN blanks)
okT = true;
for i = 1:size(LF,1)
    r = LF(i,:);  r = r(~isnan(r));
    if any(diff(r) > 1e-9), okT = false; end
end
fprintf('  [%s] LF monotone decreasing in T (all rows, NaN-aware)\n', pf(okT));

% (3) monotone decreasing in B for B>=1 T (below that, real low-field peak allowed; ignore NaN)
iB = find(Bt>=1);
okB = true;  nonmono = {};
for j = 1:size(LF,2)
    c = LF(iB,j);  m = ~isnan(c);
    Bc = Bt(iB(m));  cc = c(m);
    d = diff(cc);
    kbad = find(d > 1e-9);
    for q = 1:numel(kbad)
        okB = false;
        nonmono{end+1} = sprintf('T=%.1f K: LF rises %.2f (B=%.0f T) -> %.2f (B=%.0f T)', ...
            Tt(j), cc(kbad(q)), Bc(kbad(q)), cc(kbad(q)+1), Bc(kbad(q)+1)); %#ok<AGROW>
    end
end
fprintf('  [%s] LF monotone decreasing in B for B>=1 T (all T, NaN-aware)\n', pf(okB));
for q = 1:numel(nonmono)
    fprintf('       ^ NON-MONOTONE %s  -> re-check this cell in the PDF.\n', nonmono{q});
end

% (4) design point inside grid
inpt = Ic.inGrid(15,4.5);
fprintf('  [%s] design point (15 T, 4.5 K) inside LF grid (no extrapolation)\n', pf(inpt));

% (5) representative Ic values at the design corner.
%     NOTE: at 15 T only the 4.2 K & 20 K columns have data; 50 K is blank above 8 T,
%     so Ic(50 K,15 T) is NOT defined by the datasheet. We report where data exists.
fprintf('       Ic(%.1f K, 15 T) = %6.1f A   (LF=%.2f x Iref=%.0f A)\n', 4.5, Ic.eval(4.5,15), Ic.LF(15,4.5), Ic.Iref);
fprintf('       Ic(%.1f K, 15 T) = %6.1f A   (LF=%.2f x Iref=%.0f A)\n', 20 , Ic.eval(20 ,15), Ic.LF(15,20 ), Ic.Iref);
fprintf('       Ic(%.1f K,  8 T) = %6.1f A   (LF=%.2f x Iref=%.0f A)  [50 K has no data at 15 T]\n', 50, Ic.eval(50,8), Ic.LF(8,50), Ic.Iref);

% (6) Tcs round-trip: pick Itape < Ic(4.5,15), recover Tcs, check Ic(Tcs,15)~Itape.
%     NOTE: use B=8 T here (measured across the WHOLE temperature range), not 15 T,
%     so this test exercises the solver itself rather than the "beyond measured
%     data" boundary case (which is tested separately right below).
Btest = 8;
Itest = 0.5*Ic.eval(4.5,Btest);
Tcs   = Ic.Tcs(Itest,Btest);
resid = abs(Ic.eval(Tcs,Btest)-Itest)/Itest;
fprintf('  [%s] Tcs round-trip @ %.0f T: Itape=%.1f A -> Tcs=%.2f K (residual %.1e)\n', ...
    pf(resid<1e-3), Btest, Itest, Tcs, resid);

% (7) Tcs BEYOND the measured envelope (illustrates the new, honest behaviour):
%     at 15 T, data exists only up to 20 K -> asking for a low Itape (i.e. a hot Tcs)
%     must return the 20 K bound with a warning, NOT a fabricated number like 32 K.
Ilow = 0.5*Ic.eval(20,15);
w = warning('query','part0:TcsBeyondData');  warning('on','part0:TcsBeyondData'); %#ok<CTPCT>
Tcs_oob = Ic.Tcs(Ilow,15);
warning(w.state,'part0:TcsBeyondData');
fprintf('  [INFO] Tcs(B=15 T, Itape=%.1f A) = %.1f K -> capped at the hottest MEASURED T for 15 T (20 K), see warning above.\n', ...
    Ilow, Tcs_oob);

fprintf('\n  NOTE: Ic_ref77 (=%.0f A) is still OPEN - see openItems(data).\n', ...
    data.basis.Ic_ref77.val);
fprintf('  E0 chiuso dal fornitore; n dalla tabella del dataset, con la misura di\n');
fprintf('  laboratorio (%.1f a 76.9 K sf) come controllo indipendente.\n', ...
    data.basis.n_lab77.val);
end

function s = pf(ok), if ok, s='PASS'; else, s='FAIL'; end, end