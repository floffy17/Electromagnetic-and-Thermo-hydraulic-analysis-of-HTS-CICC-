function H = segmentMagneticField1d(P,E,Is,Q)

% SEGMENTMAGNETICFIELD1D evaluates magnetic field in a set of points due to
% thin wire
%
% USE:
% H = segmentMagneticField3d(P1,P2,Is,Q)
%
% INPUT:
% 'P': point coordinates (Npx3)
% 'E': edge connectiviti matrix (Nex2)
% 'Is': vector with currents (Nex1)
% 'Q': field points (Nfx3)
%
% OUTPUT:
% 'H': three components of magnetic field
%
% NOTE:
% See: A. Canova, F. Freschi, M. Repetto, M. Tartaglia
% "Description of Power Lines By Equivalent Source System"
% COMPEL Vol. 24, No. 3, 2005, pp. 893-905
%
% VERSION:
% Date: 19.12.2009
% Copyright(C) 2009-2025: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
% 25.08.2011: bug fix when point is aligned with source segment (Luca Giaccone)
% 04.09.2012: changed ISNAN ! ISINF with ~ISFINITE
% 04.09.2012: Is can be scalar
% 29.11.2012: uses function MU0
% 02.04.2017: caclulation of the magnetic field instead of the magnetic flux density
% 23.10.2017: changed name from BIOTSAVART
% 09.05.2025: changed name from SEGMENTMAGNETICFIELD3D 

%fprintf('evaluating magnetic field ... ');
%tic;

% start node
P1 = P(E(:,1),:);
% end node
P2 = P(E(:,2),:);

H = zeros(size(Q));
nfield = size(Q,1);
nsource = size(E,1);

if isscalar(Is)
    Is = Is*ones(nsource,1);
end

if nsource < nfield
    % loop over segments that form current path
    %    fprintf('\nloop over sources... ');
    for i = 1:nsource
        k(:,1) =  P1(i,2)*(P2(i,3)-Q(:,3))+P2(i,2)*(Q(:,3)-P1(i,3))+Q(:,2)*(P1(i,3)-P2(i,3));
        k(:,2) = -P1(i,1)*(P2(i,3)-Q(:,3))-P2(i,1)*(Q(:,3)-P1(i,3))-Q(:,1)*(P1(i,3)-P2(i,3));
        k(:,3) =  P1(i,1)*(P2(i,2)-Q(:,2))+P2(i,1)*(Q(:,2)-P1(i,2))+Q(:,1)*(P1(i,2)-P2(i,2));
        
        a = (P1(i,1)-P2(i,1))^2+(P1(i,2)-P2(i,2))^2+(P1(i,3)-P2(i,3))^2;     % scalar
        b = 2*(P1(i,1)-P2(i,1))*(P1(i,1)-Q(:,1))+2*(P1(i,2)-P2(i,2))*(P1(i,2)-Q(:,2))+2*(P1(i,3)-P2(i,3))*(P1(i,3)-Q(:,3));
        c = (P1(i,1)-Q(:,1)).^2+(P1(i,2)-Q(:,2)).^2+(P1(i,3)-Q(:,3)).^2;
        
        g = Is(i)./(2*pi).*(2*a*sqrt(c)-b.*sqrt(c)+b.*sqrt(a-b+c))./(sqrt(c).*(4*a*c-b.^2).*sqrt(a-b+c));
        
        % fix contribution when point is aligned with source segment
        g(~isfinite(g)) = 0;
        
        H = H + bsxfun(@times,k,g);
    end
else
    % loop over field points
    %    fprintf('\nloop over field points... ');
    for i = 1:nfield
        k(:,1) =  P1(:,2).*(P2(:,3)-Q(i,3))+P2(:,2).*(Q(i,3)-P1(:,3))+Q(i,2).*(P1(:,3)-P2(:,3));
        k(:,2) =-(P1(:,1).*(P2(:,3)-Q(i,3))+P2(:,1).*(Q(i,3)-P1(:,3))+Q(i,1).*(P1(:,3)-P2(:,3)));
        k(:,3) =  P1(:,1).*(P2(:,2)-Q(i,2))+P2(:,1).*(Q(i,2)-P1(:,2))+Q(i,1).*(P1(:,2)-P2(:,2));
        
        a = sum((P1(:,:)-P2(:,:)).^2,2);
        b = 2*dot(P1(:,:)-P2(:,:),P1(:,:)-repmat(Q(i,:),nsource,1),2);
        c = sum((P1(:,:)-repmat(Q(i,:),nsource,1)).^2,2);
        
        g = Is./(2*pi).*(2*a.*sqrt(c)-b.*sqrt(c)+b.*sqrt(a-b+c)) ./ (sqrt(c).*(4*a.*c-b.^2).*sqrt(a-b+c));
        
        % fix contribution when point is aligned with source segment
        g(~isfinite(g)) = 0;
        
        Bs = bsxfun(@times,k,g);
        H(i,:) = sum(Bs,1);
    end
end
