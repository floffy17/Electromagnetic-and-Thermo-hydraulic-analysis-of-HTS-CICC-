function cprintf(cond,varargin)

% CPRINTF conditional fprintf
%
% USE:
% cprintf(cond,varargin)
%
% INPUTS:
% 'cond' logical condition
% 'varargin': arguments passed to FPRINTF
%
% OUTPUTS:
%
% NOTES:
%
% VERSION:
% Date: 19.01.2011
% Copyright(C) 2011: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
%

if cond
    fprintf(varargin{:});
end

end