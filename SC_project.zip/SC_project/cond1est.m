function c = cond1est(A,factor)

% COND1EST estimates the 1-norm condition number of A
%
% USE:
% c = cond1est(A,factor)
%
% INPUTS:
% 'A': coefficient matrix
% 'factor': struct with information of the factorization created by FACTORIZE
%
% OUTPUTS:
% 'c': lower bound C for the 1-norm condition number
%
% NOTE:
% Adapted from T. Davis, "Direct methods for sparse linear systems",
% Exercise 6.5 pp. 96
%
% VERSION:
% Date: 01.03.2014
% Copyright(C) 2014: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
% 10.07.2024: compatible with new output of FORWARDBACKWARDSOLVE

if isempty(factor.L)
    c = 0;
else
    c = norm(A,1)*norm1est(factor);
end
end

function est = norm1est(factor) % 1-norm estimate of inv(A)
n = size(factor.L,1);

for k = 1:2
    if (k == 1)
        est = 0 ;
        x=ones (n,1) /n;
        jold = -1 ;
    else
        j = find(abs(x) == norm(x,inf),1);
        if (j == jold)
            break
        end
        x = zeros(n,1) ;
        x(j) = 1 ;
        jold = j;
    end
    x = forwardBackwardSolve(factor,x,'verbose','n');
    est_old = est ;
    est = norm(x,1);
    if (k > 1 && est <= est_old)
        break
    end
    s = ones(n,1);
    s(x < 0) = -1;
    
    % x=P'*(L' \(U'\(Q'*s)));
    x = forwardBackwardSolve(factor,s,'verbose','n','transpose','y');
    
end
end