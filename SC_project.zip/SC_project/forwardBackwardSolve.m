function x = forwardBackwardSolve(factor,b,varargin)

% FORWARDBACKWARDSOLVE performs forward and backward substitutions
% (triangular solve) starting from the factorization obtained by
% FACTORIZEMATRIX
%
% USE:
% factor = forwardBackwardSolve(factor,b,varargin)
%
% INPUTS:
% 'factor': struct containing the factorization provided by FACTORIZEMATRIX
% 'b': rhs
% 'varargin': optional arguments
%   * 'verbose': verbose output. Available: 'y' yes, 'n' no (default: 'y')
%   * 'transpose': if 'y'/'transp' yes, solve A'x = b (default: 'n'/'notransp')
%
% OUTPUTS:
% 'x': solution vector
%
% NOTES:
%
% VERSION:
% Date: 19.12.2009
% Copyright(C) 2009-2024: Fabio Freschi (fabio.freschi@polito.it)
%
% HISTORY:
% 19.03.2010: built-in forward/backward solve used when factors or rhs are complex
% 19.01.2011: added conditional print
% 03.03.2011: added check for diagonal matrices and solution
% 15.05.2012: added solution for HSL_MA86 routine
% 02.10.2012: added possibility of factorization of full matrices
% 05.10.2012: bug fix for full matrices/HSL_MA87
% 10.12.2012: added permutation for full matrices
% 10.12.2012: added LDL soluiton of full matrices
% 01.03.2014: fixed bug on LDL solution of full matrices
% 01.03.2013: added TRANSPOSE as optional input
% 16.01.2015: fixed bug with diagonal full matrices
% 14.07.2015: added compatibility with built-in iterative solvers
% 20.01.2016: removed the use of SuiteSparse routines
% 08.07.2024: refurbished routine
% 10.07.2024: solution vector as output

% default inputs
verbose = 'y';
transpose = 'n';

% check varargin
for i = 1:2:length(varargin)
    vin = varargin{i};
    if strcmpi(vin,'verbose')
        verbose = varargin{i+1};
    elseif strcmpi(vin,'transpose')
        transpose = varargin{i+1};
    end
end

% printing logical variable
iprn = strcmpi(verbose,'y');

cprintf(iprn,'* back/forward substitution... ');
t0 = tic;

if strcmpi(factor.method,'diag')
    x = factor.L*b;
elseif strcmpi(factor.method,'chol')
    if factor.issparse
        x(factor.p,:) = factor.L'\(factor.L\b(factor.p,:));
    else
        x = factor.L'\(factor.L\b);
    end        
elseif strcmpi(factor.method,'ldl')
    if factor.issparse
        y = factor.S*b;
        y = factor.L\y(factor.p,:);
        y = factor.D\y;
        y(factor.p,:) = factor.L'\y;
        x = factor.S*y;
    else
        x(factor.p,:) = factor.L'\(factor.D\(factor.L\b(factor.p,:)));
    end
elseif strcmpi(factor.method,'lu')
    if factor.issparse
        if (strcmpi(transpose,'n') || strcmpi(transpose,'notransp'))
            y = factor.R\b;
            y = factor.L\y(factor.p,:);
            x(factor.q,:) = factor.U\y;
        elseif (strcmpi(transpose,'y') || strcmpi(transpose,'transp'))
            y = factor.R\b;
            y = factor.U'\y(factor.q,:);
            x(factor.p,:) = factor.L'\y;
        end
    else
        if strcmpi(transpose,'n') || strcmpi(transpose,'notransp')
            x = factor.U\(factor.L\b(factor.p,:));
        elseif strcmpi(transpose,'y') || strcmpi(transpose,'transp')
            x(factor.ip,:) = factor.L'\(factor.U'\b);
        end
    end
end

cprintf(iprn,'done %6.2f sec\n',toc(t0));