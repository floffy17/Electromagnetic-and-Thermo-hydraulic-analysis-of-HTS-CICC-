function T = part0_openItems(data)
% PART0_OPENITEMS  List every datum still tagged OPEN or 'assumed', i.e. the
%   values to replace when Faraday Factory / the instructor reply.
%
%   part0_openItems(data)        % prints a table
%   T = part0_openItems(data)    % also returns it as a cell table
%
%   Use this before trusting any final number: anything listed here is a
%   placeholder or a convention, not a certified measurement.

rows = {};
groups = {'op','tape','basis','joint','mech'};
for g = 1:numel(groups)
    grp = data.(groups{g});
    fn = fieldnames(grp);
    for i = 1:numel(fn)
        e = grp.(fn{i});
        if ~isstruct(e) || ~isfield(e,'src'), continue; end
        if any(strcmp(e.src,{'OPEN','assumed'}))
            v = e.val;
            if isnumeric(v) && isscalar(v), vs = num2str(v,'%.4g');
            elseif isnumeric(v),            vs = ['[' num2str(v(:).','%.4g ') ']'];
            else,                           vs = char(string(v)); end
            rows(end+1,:) = {[groups{g} '.' fn{i}], upper(e.src), vs, e.unit, e.note}; %#ok<AGROW>
        end
    end
end

fprintf('\n=== PART 0 - ITEMS TO REVISIT (OPEN / assumed) ===\n');
fprintf('%-22s %-8s %-14s %-8s %s\n','field','tag','value','unit','note');
fprintf('%s\n', repmat('-',1,100));
for k = 1:size(rows,1)
    fprintf('%-22s %-8s %-14s %-8s %s\n', rows{k,1}, rows{k,2}, rows{k,3}, rows{k,4}, rows{k,5});
end
fprintf('\nWhen the Faraday reply arrives, edit these in part0_dataAcquisition.m:\n');
fprintf('  * basis.Ic_ref77  <- true min Ic(77K,sf)  (currently proxy 100 A)\n');
fprintf('  * basis.E0        <- Faraday Ic criterion\n');
fprintf('  * basis.n         <- datasheet/lab n index\n');

if nargout, T = rows; end
end

function data = part0_dataAcquisition(verbose)
% PART0_DATAACQUISITION  Assemble and provenance-tag every input datum for the
%   HTS CICC double-pancake solenoid project (NELAHTP 2025/2026).
%
%   data = part0_dataAcquisition()        % silent
%   data = part0_dataAcquisition(true)    % prints a provenance report + sanity checks
%
%   This is the single source of truth for Part 0. Everything downstream
%   (Parts 1-5) pulls numbers from the returned struct so that no magic
%   constant is ever buried in a computational routine.
%
%   PROVENANCE TAGS (data.<field>.src):
%     'faraday'   verbatim from the HERMES Data Book (Faraday Factory, v.2025-07)
%     'brief'     from the project brief / operational-parameters slide
%     'assumed'   engineering assumption or convention (see .note for the ASSUMPTION-x id)
%     'literature'externally cited value
%     'OPEN'      NOT yet known -> placeholder standing in until instructor/Faraday reply
%
%   Fields carrying an 'OPEN' or 'assumed' tag are the ones to revisit when the
%   Faraday reply / instructor answers arrive; call part0_openItems(data) for the list.
%
%   NELAHTP SC project - Part 0.  No dependency on the Freschi package here
%   (that starts in Part 2); Part 0 is pure data + the Ic evaluator.

if nargin < 1, verbose = false; end

data = struct();
data.meta.project   = 'HTS CICC double-pancake solenoid @ 15 T / 50 kA';
data.meta.datasheet = 'Faraday Factory HERMES - HTS Tape for Magnets, Data Book, version July 2025';
data.meta.generated = datestr(now,'yyyy-mm-dd HH:MM:SS');

% ------------------------------------------------------------------------
% 1. BRIEF / OPERATIONAL PARAMETERS  (project brief, "Operational parameters" slide)
% ------------------------------------------------------------------------
data.op.I_rated   = tag(50e3 ,'A'      ,'brief','Rated current (50 kA)');
data.op.dIdt      = tag(200  ,'A/s'    ,'brief','Ramp rate 0.2 kA/s');
data.op.t_ramp    = tag(data.op.I_rated.val/data.op.dIdt.val,'s','brief','0->50 kA ramp duration (=250 s)');
data.op.B_target  = tag(15   ,'T'      ,'brief','Max field on conductor incl. self-field');
data.op.dT_margin = tag(5    ,'K'      ,'brief','Required temperature margin (>= 5 K)');
data.op.ID_wind   = tag(1.0  ,'m'      ,'brief','Solenoid inner diameter');
data.op.H_max     = tag(1.5  ,'m'      ,'brief','Max solenoid height');
data.op.mdot_max  = tag(15e-3,'kg/s'   ,'brief','Max He mass flow rate (15 g/s)');
data.op.Tin_range = tag([4.5 50],'K'   ,'brief','Inlet temperature envelope');
data.op.pin_range = tag([5 20] ,'bar'  ,'brief','Inlet pressure envelope');

% ------------------------------------------------------------------------
% 2. HERMES TAPE - BASIC SPECIFICATIONS  (Data Book, "Basic Specifications")
% ------------------------------------------------------------------------
data.tape.width      = tag(4.0e-3 ,'m'    ,'faraday','Tape width 4.0 +/- 0.2 mm');
data.tape.width_tol  = tag(0.2e-3 ,'m'    ,'faraday','Width tolerance');
data.tape.len_range  = tag([100 700],'m'  ,'faraday','Tape length 100...700 m');
data.tape.Ic77_avg   = tag([100 200],'A'  ,'faraday','Average Ic @ 77K, self-field, 4mm');
data.tape.eps_crit   = tag(0.4e-2  ,'-'   ,'faraday','Critical deformation >= 0.4 %');
data.tape.dbend_crit = tag(10e-3   ,'m'   ,'faraday','Critical double-bend diameter <= 10 mm');
data.tape.sigma_uts  = tag(500e6   ,'Pa'  ,'faraday','Strength > 500 MPa');
data.tape.t_substr   = tag(40e-6   ,'m'   ,'faraday','Hastelloy C-276 substrate 35...45 um (nominal 40)');
data.tape.t_Ag_side  = tag(1e-6    ,'m'   ,'faraday','Silver stabilization 1 um back / (2 um surround per architecture)');
data.tape.t_Cu_side  = tag(5e-6    ,'m'   ,'faraday','Copper stabilization 5 um each side');

% Tape architecture layer stack (Data Book, "Tape Architecture"), top->bottom, per side as drawn.
% Total nominal thickness = sum below.
data.tape.layers = tag(struct( ...
    'Cu_top'   ,5.0e-6 , ...   % surround electroplating
    'Ag_top'   ,2.0e-6 , ...   % surround sputter
    'REBCO'    ,2.5e-6 , ...   % YBCO + Y2O3 nanoparticles, PLD
    'buffer'   ,0.1e-6 , ...   % IBAD/e-beam
    'Hastelloy',40e-6  , ...   % C-276
    'Ag_back'  ,1.0e-6 , ...   % sputter
    'Cu_back'  ,5.0e-6 ), ...  % electroplating
    'm','faraday','Layer stack; REBCO is YBCO+Y2O3-np (PLD) -> Tc ~ 92-93 K');
data.tape.t_total = tag( ...
    sum(structfun(@(x)x, data.tape.layers.val)) ,'m','faraday', ...
    'Total nominal tape thickness (sum of architecture layers)');
data.tape.t_REBCO = tag(2.5e-6,'m','faraday','Superconducting (YBCO) layer thickness');

% ------------------------------------------------------------------------
% 3. HERMES ELECTRIC / SUPERCONDUCTING PROPERTIES
% ------------------------------------------------------------------------
data.tape.rho_20C = tag(324e-3,'Ohm/m','faraday','Room-T resistivity 324 +/- 14 mOhm/m (886 samples)');

% --- Recommended Lift Factors table  (Data Book, "Recommended Lift Factors") ---
% LF(B,T) = min Ic(B,T) / min Ic(77K, self-field).  Rows = field [T], cols = temperature [K].
% TRANSCRIBED verbatim from the rasterized table on 2026-... , cross-checked for
% monotonicity in T (all rows) and in B above 1 T. The low-field bump near 0.3-0.5 T
% at 4.2/20 K is genuine REBCO behaviour (grain-boundary/self-field), not a mis-read.
% >>> A few interior cells were read from a rotated scan; VERIFY against the PDF at high
%     zoom before trusting 3rd-significant-figure results. KNOWN suspect cell:
%     (50 K, 4 T)=0.66 vs (50 K, 5 T)=0.76 is non-monotone in B -> one of the two is a
%     mis-read (Ic cannot rise with field). part0_sanityChecks flags it automatically. <<<
data.lf.T = tag([4.2 20 30 40 50 60 70 77.3],'K','faraday','Lift-factor table temperatures');
data.lf.B = tag([0.00 0.01 0.03 0.10 0.30 0.50 0.70 ...
                 1 2 3 4 5 6 7 8 9 10 12 14 16 18 20].','T','faraday','Lift-factor table fields');
%           T=  4.2    20    30    40    50    60    70   77.3
data.lf.LF = tag([ ...
    15.6  11.2  9.1   7.3   5.3   3.3   1.9   1.00 ;   % 0.00 T
    15.2  11.2  9.1   7.2   4.9   3.3   1.9   0.91 ;   % 0.01 T
    13.8  11.0  9.0   6.7   4.8   3.2   1.7   0.74 ;   % 0.03 T
    11.3  10.6  8.6   6.2   4.3   2.6   1.2   0.46 ;   % 0.10 T
     9.8   9.6  7.7   5.4   3.5   1.9   0.79  0.27 ;   % 0.30 T
    11.5   7.3  6.8   4.6   2.6   1.4   0.60  0.22 ;   % 0.50 T
    10.3   6.6  6.2   4.2   2.8   1.3   0.60  0.20 ;   % 0.70 T
     7.6   6.3  4.9   3.3   1.9   0.88  0.34  0.16 ;   % 1 T
     5.8   4.3  3.4   2.0   1.3   0.66  0.26  0.12 ;   % 2 T
     5.0   3.5  2.4   1.6   0.88  0.54  0.19  0.10 ;   % 3 T
     4.4   3.0  2.1   1.4   0.66  0.46  0.15  0.08 ;   % 4 T
     4.0   2.6  1.8   1.2   0.76  0.38  0.15  0.08 ;   % 5 T
     3.7   2.3  1.7   1.1   0.60  0.33  0.11  0.06 ;   % 6 T
     3.4   2.1  1.5   1.0   0.60  0.28  0.11  0.06 ;   % 7 T
     3.4   1.9  1.4   0.89  0.53  0.24  0.11  0.05 ;   % 8 T
     3.2   1.8  1.3   0.84  0.44  0.22  0.10  0.05 ;   % 9 T
     3.0   1.7  1.2   0.72  0.43  0.20  0.09  0.05 ;   % 10 T
     2.5   1.4  1.0   0.62  0.37  0.19  0.09  0.05 ;   % 12 T
     2.3   1.3  0.93  0.55  0.33  0.15  0.09  0.05 ;   % 14 T
     2.1   1.2  0.85  0.53  0.29  0.15  0.09  0.05 ;   % 16 T
     2.1   1.2  0.79  0.53  0.29  0.15  0.09  0.05 ;   % 18 T
     2.0   1.1  0.75  0.53  0.24  0.15  0.09  0.05 ], ...% 20 T
     '-','faraday','LF(B,T) = minIc(B,T)/minIc(77K,sf); rows=B, cols=T');

% ------------------------------------------------------------------------
% 4. DESIGN-BASIS CHOICES / CONVENTIONS  (assumptions - revisit on Faraday reply)
% ------------------------------------------------------------------------
% ASSUMPTION-2 (updated): the LF table is normalised to *min* Ic(77K,sf), whose
%   absolute value is NOT printed in the Data Book. Basic-Specs gives only the
%   *average* range 100-200 A. We adopt the conservative floor of that range as a
%   proxy for the (unknown) min, pending Faraday's answer -> OPEN.
data.basis.Ic_ref77 = tag(100 ,'A','OPEN', ...
    ['Reference min Ic(77K,sf) anchoring the LF table. Proxy = low end of the ' ...
     'average range; true min not in datasheet. ASSUMPTION-2 / awaiting Faraday.']);

% E0 criterion - not stated by Faraday. Convention adopted.  ASSUMPTION / OPEN-1.
data.basis.E0 = tag(1e-4,'V/m','assumed', ...
    'Ic criterion 1 uV/cm = 1e-4 V/m (IEC 61788 convention). Faraday value unknown -> OPEN-1.');

% n index - not in datasheet. Literature standing value + sweep.  ASSUMPTION-6.
data.basis.n      = tag(20,'-','literature', ...
    'E-J index (E=E0 (I/Ic)^n). Standing value; Robert/Fareed/Ruiz 2019, Wang 2024. ASSUMPTION-6.');
data.basis.n_sweep= tag([15 30],'-','assumed','Sensitivity sweep for n.');

% Tc - YBCO (confirmed by datasheet chemistry).  ASSUMPTION-1 (refined).
data.basis.Tc = tag(92,'K','literature', ...
    'YBCO Tc ~ 92 K (datasheet REBCO = YBCO+Y2O3-np). ASSUMPTION-1; may be released as fit param.');

% Field-angle convention bridge.  Faraday plots: angle from c-axis (Bperp/c = 0/180 deg).
%   Freschi s6: theta from tape PLANE (theta=0 -> B parallel, theta=+/-90 -> B perp).
%   Relationship:  theta_Freschi = angle_Faraday - 90 deg.  ASSUMPTION-5.
data.basis.angleConv = tag('theta_Freschi = angleFaraday - 90 deg','-','assumed', ...
    ['Faraday angle measured from c-axis (0/180 deg = B perp tape). ' ...
     'LF *table* is min over angle (worst-case), so no extra angle assumption needed for the table.']);

% ------------------------------------------------------------------------
% 5. JOINTS  (Data Book, "Joints") - resolves the earlier open question on joints
% ------------------------------------------------------------------------
data.joint.R_avg     = tag(8.9e-9 ,'Ohm'   ,'faraday','Lap joint (PbSn), avg resistance, 75 mm x 4 mm');
data.joint.R_area    = tag(26.7e-9,'Ohm*cm2','faraday','Area-normalised joint resistance (avg)');
data.joint.overlap   = tag(75e-3  ,'m'     ,'faraday','Lap-joint overlap length');

% ------------------------------------------------------------------------
% 6. MECHANICAL (extra Data Book values useful in Part 3)
% ------------------------------------------------------------------------
data.mech.delam_avg = tag(71e6,'Pa','faraday','Delamination strength avg ~71 MPa (Weibull dist.)');

% ------------------------------------------------------------------------
% 7. BUILD THE Ic EVALUATOR (design basis) + convenience handles
% ------------------------------------------------------------------------
data.Ic = buildIcEvaluator(data);

% ------------------------------------------------------------------------
% 8. REPORT
% ------------------------------------------------------------------------
if verbose
    part0_report(data);
    part0_sanityChecks(data);
end
end % ===================== end main =====================


% ========================================================================
function s = tag(val,unit,src,note)
% Wrap a datum with unit + provenance so nothing travels un-attributed.
s = struct('val',val,'unit',unit,'src',src,'note',note);
end


% ========================================================================
function Ic = buildIcEvaluator(data)
% Design-basis empirical evaluator:  Ic(T,B) = Ic_ref77 * LF(B,T)
% Interpolation: linear in B, linear in T, on log(LF) (LF spans ~2.5 decades and
% is quasi-exponential in T). Angle: the LF table is already the worst-case-over-angle
% envelope, so Ic(T,B,theta) := Ic(T,B) for the table-based design basis (ASSUMPTION-5).
%
% Returns a struct of function handles:
%   Ic.LF(B,T)         -> lift factor (scalar/vector, extrapolation guarded)
%   Ic.eval(T,B[,th])  -> critical current [A]  (theta ignored: table is worst-case)
%   Ic.Tcs(Itape,B[,th])-> current-sharing temperature [K]
%   Ic.inGrid(B,T)     -> logical, is (B,T) inside the tabulated envelope

Bt = data.lf.B.val(:);          % Nb x 1
Tt = data.lf.T.val(:);          % 1 x NT (as row)
LF = data.lf.LF.val;            % Nb x NT
Iref = data.basis.Ic_ref77.val; % A

logLF = log(LF);
% griddedInterpolant expects grid vectors; build once.
[BB,TT] = ndgrid(Bt,Tt);
F = griddedInterpolant(BB,TT,logLF,'linear','none');  % 'none' -> NaN outside -> caught below

Ic.Bgrid = Bt;  Ic.Tgrid = Tt;  Ic.Iref = Iref;

Ic.inGrid = @(B,T) (B>=min(Bt) & B<=max(Bt) & T>=min(Tt) & T<=max(Tt));

    function lf = LFfun(B,T)
        B = abs(B);                         % field magnitude
        lf = exp(F(B(:),T(:)));
        oob = ~Ic.inGrid(B(:),T(:));
        if any(oob)
            % Guarded extrapolation policy (ASSUMPTION-3):
            %  - clamp to nearest grid edge, which is CONSERVATIVE toward lower B / higher T;
            %  - for the design point (~15 T, 4.5 K) we are INSIDE the grid, so this should
            %    never fire in normal use. Warn loudly if it does.
            warning('part0:LFextrapolation', ...
                '%d query point(s) outside LF grid [B:%.2g-%.2g T, T:%.2g-%.2g K] - clamped.', ...
                nnz(oob), min(Bt),max(Bt),min(Tt),max(Tt));
            Bc = min(max(B(:),min(Bt)),max(Bt));
            Tc = min(max(T(:),min(Tt)),max(Tt));
            lf(oob) = exp(F(Bc(oob),Tc(oob)));
        end
        lf = reshape(lf,size(B));
    end
Ic.LF = @LFfun;

% Critical current [A]. theta accepted for interface compatibility but unused (table = worst case).
Ic.eval = @(T,B,varargin) Iref .* LFfun(B,T);

% Current-sharing temperature: solve Ic(Tcs,B) = Itape for Tcs in [Tmin, Tc].
% Ic monotone decreasing in T over the table -> unique root; bisection is robust.
    function Tcs = TcsFun(Itape,B,varargin)
        Tlo = min(Tt);  Thi = max(Tt);
        f = @(T) Ic.eval(T,B) - Itape;      % decreasing in T
        flo = f(Tlo); fhi = f(Thi);
        if flo <= 0
            Tcs = Tlo;  % already below margin even at coldest tabulated T
            return
        elseif fhi >= 0
            Tcs = Thi;  % still superconducting at hottest tabulated T (>=77 K): cap
            return
        end
        for it = 1:60
            Tm = 0.5*(Tlo+Thi);
            if f(Tm) > 0, Tlo = Tm; else, Thi = Tm; end
            if (Thi-Tlo) < 1e-4, break; end
        end
        Tcs = 0.5*(Tlo+Thi);
    end
Ic.Tcs = @TcsFun;
end


% ========================================================================
function part0_report(data)
fprintf('\n============================================================\n');
fprintf(' PART 0 - DATA ACQUISITION REPORT\n');
fprintf(' %s\n', data.meta.datasheet);
fprintf(' generated %s\n', data.meta.generated);
fprintf('============================================================\n');
printGroup('OPERATIONAL (brief)', data.op);
printGroup('TAPE - basic/architecture', data.tape);
printGroup('DESIGN BASIS (assumptions/open)', data.basis);
printGroup('JOINTS', data.joint);
printGroup('MECHANICAL', data.mech);
fprintf('\n-- Ic evaluator built: Ic.eval(T,B), Ic.Tcs(Itape,B), Ic.LF(B,T)\n');
end

function printGroup(title, g)
fprintf('\n--- %s ---\n', title);
fn = fieldnames(g);
for i = 1:numel(fn)
    e = g.(fn{i});
    if ~isstruct(e) || ~isfield(e,'val'), continue; end
    v = e.val;
    if isnumeric(v) && isscalar(v),      vs = num2str(v,'%.4g');
    elseif isnumeric(v) && isvector(v),  vs = ['[' num2str(v(:).','%.4g ') ']'];
    elseif isstruct(v),                  vs = '(struct)';
    else,                                vs = char(string(v));
    end
    flag = '';
    if strcmp(e.src,'OPEN'),   flag = '  <<< OPEN';
    elseif strcmp(e.src,'assumed'), flag = '  (assumed)';
    end
    fprintf('  %-12s = %-16s [%-4s] %-10s  %s%s\n', fn{i}, vs, e.unit, e.src, e.note, flag);
end
end


% ========================================================================
function part0_sanityChecks(data)
fprintf('\n--- SANITY CHECKS ---\n');
Ic = data.Ic;  LF = data.lf.LF.val;  Bt = data.lf.B.val;  Tt = data.lf.T.val;

% (1) anchor
a = LF(1,end);  ok = abs(a-1.0)<1e-9;
fprintf('  [%s] LF(0 T, 77.3 K) = %.3f (expect 1.000)\n', pf(ok), a);

% (2) monotone decreasing in T for every field row
okT = all(all(diff(LF,1,2) <= 1e-9));
fprintf('  [%s] LF monotone decreasing in T (all rows)\n', pf(okT));

% (3) monotone decreasing in B for B>=1 T (below that, real low-field peak allowed)
iB = find(Bt>=1);
dB = diff(LF(iB,:),1,1);
okB = all(dB(:) <= 1e-9);
fprintf('  [%s] LF monotone decreasing in B for B>=1 T (all T)\n', pf(okB));
if ~okB
    [rr,cc] = find(dB > 1e-9);
    for q = 1:numel(rr)
        fprintf('       ^ NON-MONOTONE cell: T=%.1f K, LF rises %.2f (B=%.0f T) -> %.2f (B=%.0f T)\n', ...
            Tt(cc(q)), LF(iB(rr(q)),cc(q)), Bt(iB(rr(q))), LF(iB(rr(q))+1,cc(q)), Bt(iB(rr(q))+1));
    end
    fprintf('       => KNOWN transcription ambiguity from the rotated scan (Ic cannot rise with B).\n');
    fprintf('          RE-READ this cell in the PDF before trusting results near it. See LF-table note.\n');
end

% (4) design point inside grid
inpt = Ic.inGrid(15,4.5);
fprintf('  [%s] design point (15 T, 4.5 K) inside LF grid (no extrapolation)\n', pf(inpt));

% (5) representative Ic values at the design corner
for TT = [4.5 20 50]
    Ic15 = Ic.eval(TT,15);
    fprintf('       Ic(%.1f K, 15 T) = %6.1f A   (LF=%.2f x Iref=%.0f A)\n', ...
        TT, Ic15, Ic.LF(15,TT), Ic.Iref);
end

% (6) Tcs round-trip: pick Itape < Ic(4.5,15), recover Tcs, check Ic(Tcs,15)~Itape
Itest = 0.5*Ic.eval(4.5,15);
Tcs   = Ic.Tcs(Itest,15);
resid = abs(Ic.eval(Tcs,15)-Itest)/Itest;
fprintf('  [%s] Tcs round-trip: Itape=%.1f A -> Tcs=%.2f K (residual %.1e)\n', ...
    pf(resid<1e-3), Itest, Tcs, resid);

fprintf('\n  NOTE: Ic_ref77 (=%.0f A) and E0 and n are OPEN/assumed - see part0_openItems(data).\n', ...
    data.basis.Ic_ref77.val);
end

function s = pf(ok), if ok, s='PASS'; else, s='FAIL'; end, end