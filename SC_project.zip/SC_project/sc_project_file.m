%FILE FOR SC PROJECT

%% DATA

% --- Parametri Operativi Elettromagnetici ---
I_nom = 50e3;         % [A] Corrente nominale (50 kA)
B_max = 15;           % [T] Campo magnetico massimo sul conduttore (incluso self-field)
dI_dt = 0.2e3;        % [A/s] Ramp rate della corrente (0.2 kA/s)

% --- Geometria del Solenoide ---
D_in = 1.0;           % [m] Diametro interno del solenoide
R_in = D_in / 2;      % [m] Raggio interno del solenoide
H_max = 1.5;          % [m] Altezza massima del solenoide

% --- Parametri del Sistema di Raffreddamento (Elio) ---
m_dot_max = 15e-3;    % [kg/s] Portata massica massima disponibile di Elio (15 g/s)
T_in_min = 4.5;       % [K] Temperatura minima di ingresso consentita
T_in_max = 50.0;      % [K] Temperatura massima di ingresso consentita
p_in_min = 5e5;       % [Pa] Pressione minima di ingresso (5 bar)
p_in_max = 20e5;      % [Pa] Pressione massima di ingresso (20 bar)

% --- Metriche e Obiettivi di Design ---
T_margin_min = 5.0;   % [K] Margine di temperatura minimo richiesto in operazione

% --- Proprietà dei Materiali Specificati ---
% Nastri SC: HTS REBCO
% Stabilizzatore: Rame (Copper)
RRR_Cu = 100;         % [-] Residual Resistivity Ratio dello stabilizzatore in Rame
% Jacket: Acciaio inossidabile (Stainless steel)



%% STEP 1: Measure analysis


%% STEP 2: Geometry design

% --- Parametri di input ---
Nturns = 10;            % Esempio: 10 giri
pitch = 0.05;           % Spessore radiale del cavo [m]
Nseg_per_turn = 32;     % Discretizzazione (poligono a 32 lati per giro)

% --- Calcolo dei punti ---
Ntotal_seg = Nturns * Nseg_per_turn;
% Vettore degli angoli (da 0 a 2*pi * Nturns)
theta = linspace(0, 2*pi*Nturns, Ntotal_seg + 1)'; 

% Raggio variabile (Spirale di Archimede)
% r(theta) = Rin + (pitch / 2*pi) * theta
r = R_in + (pitch / (2*pi)) * theta;

% --- Trasformazione in Coordinate Cartesiane ---
x = r .* cos(theta);
y = r .* sin(theta);
z = zeros(size(theta)); % Per un pancake piatto, z è costante

% Creazione della Matrice P (Np x 3)
P = [x, y, z];

% --- Creazione della Matrice degli Archi E (Ne x 2) ---
% Ogni arco collega il nodo i al nodo i+1
E = [(1:Ntotal_seg)', (2:Ntotal_seg+1)'];

%% STEP 3: Magnetic field

%% STEP 4: CICC Layout

%% STEP 5: Differential algebraic equation 

%% STEP 6: AC Losses 

%% STEP 7: Cooling CICC